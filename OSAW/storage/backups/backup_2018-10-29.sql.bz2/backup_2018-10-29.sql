-- MySQL dump 10.13  Distrib 8.0.13, for Linux (x86_64)
--
-- Host: localhost    Database: OSAW
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessmonitors`
--

DROP TABLE IF EXISTS `accessmonitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `accessmonitors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aaa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_a` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accessmonitors_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `accessmonitors_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessmonitors`
--

LOCK TABLES `accessmonitors` WRITE;
/*!40000 ALTER TABLE `accessmonitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessmonitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acheckers`
--

DROP TABLE IF EXISTS `acheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `acheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `acheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `acheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acheckers`
--

LOCK TABLES `acheckers` WRITE;
/*!40000 ALTER TABLE `acheckers` DISABLE KEYS */;
/*!40000 ALTER TABLE `acheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Ministerios y agencias estatales',NULL,NULL),(2,'Entidades autonómicas y locales',NULL,NULL),(3,'Entidades públicas empresariales',NULL,NULL),(4,'Centros universitarios públicos',NULL,NULL),(5,'Empresas privadas',NULL,NULL);
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eiiicheckers`
--

DROP TABLE IF EXISTS `eiiicheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `eiiicheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_aciertos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `eiiicheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `eiiicheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eiiicheckers`
--

LOCK TABLES `eiiicheckers` WRITE;
/*!40000 ALTER TABLE `eiiicheckers` DISABLE KEYS */;
/*!40000 ALTER TABLE `eiiicheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=911 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (898,'2018_10_01_211102_create_rols_table',1),(899,'2018_10_02_000000_create_users_table',1),(900,'2018_10_02_100000_create_password_resets_table',1),(901,'2018_10_04_223958_create_categorias_table',1),(902,'2018_10_05_223735_create_sitios_table',1),(903,'2018_10_06_223729_create_paginas_table',1),(904,'2018_10_07_223910_create_user_pagina_table',1),(905,'2018_10_20_211356_create_accessmonitors_table',1),(906,'2018_10_20_211408_create_acheckers_table',1),(907,'2018_10_20_211409_create_eiiicheckers_table',1),(908,'2018_10_20_211509_create_vamolas_table',1),(909,'2018_10_20_211516_create_waves_table',1),(910,'2018_10_24_002941_create_observatorios_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `observatorios`
--

DROP TABLE IF EXISTS `observatorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `observatorios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `porcentaje_comprensible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_operable` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_perceptible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_robusto` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_operable` int(11) NOT NULL DEFAULT '0',
  `num_problemas_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_robusto` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_operable` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_robusto` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `observatorios_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `observatorios_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `observatorios`
--

LOCK TABLES `observatorios` WRITE;
/*!40000 ALTER TABLE `observatorios` DISABLE KEYS */;
/*!40000 ALTER TABLE `observatorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paginas`
--

DROP TABLE IF EXISTS `paginas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `paginas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `URL` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `archivo_HTML` text COLLATE utf8mb4_unicode_ci,
  `hash` char(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `sitio_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paginas_sitio_id_foreign` (`sitio_id`),
  CONSTRAINT `paginas_sitio_id_foreign` FOREIGN KEY (`sitio_id`) REFERENCES `sitios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paginas`
--

LOCK TABLES `paginas` WRITE;
/*!40000 ALTER TABLE `paginas` DISABLE KEYS */;
INSERT INTO `paginas` VALUES (1,'http://www.mjusticia.gob.es',NULL,'default',1,NULL,NULL);
/*!40000 ALTER TABLE `paginas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rols`
--

DROP TABLE IF EXISTS `rols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `rols` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rols`
--

LOCK TABLES `rols` WRITE;
/*!40000 ALTER TABLE `rols` DISABLE KEYS */;
INSERT INTO `rols` VALUES (1,'Colaborador',NULL,NULL),(2,'Experto',NULL,NULL),(3,'Administrador',NULL,NULL);
/*!40000 ALTER TABLE `rols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitios`
--

DROP TABLE IF EXISTS `sitios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sitios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dominio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodicidad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia` int(11) NOT NULL,
  `automatizado` tinyint(1) NOT NULL,
  `num_paginas` int(11) NOT NULL,
  `herramientas` json NOT NULL,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitios_nombre_unique` (`nombre`),
  KEY `sitios_categoria_id_foreign` (`categoria_id`),
  CONSTRAINT `sitios_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitios`
--

LOCK TABLES `sitios` WRITE;
/*!40000 ALTER TABLE `sitios` DISABLE KEYS */;
INSERT INTO `sitios` VALUES (1,'Ministerio de Justicia','www.mjusticia.gob.es','Diario','01:36',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL),(2,'Agencia Estatal de Administración Tributaria','www.agenciatributaria.es','Semanal','11:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL);
/*!40000 ALTER TABLE `sitios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_pagina`
--

DROP TABLE IF EXISTS `user_pagina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user_pagina` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `informe` json NOT NULL,
  `fecha_test` date NOT NULL,
  `revisado` tinyint(1) NOT NULL,
  `porcentaje_comprensible` double(8,2) NOT NULL,
  `porcentaje_operable` double(8,2) NOT NULL,
  `porcentaje_perceptible` double(8,2) NOT NULL,
  `porcentaje_robusto` double(8,2) NOT NULL,
  `num_errores_a` int(11) NOT NULL,
  `num_errores_aa` int(11) NOT NULL,
  `num_errores_aaa` int(11) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_pagina_user_id_foreign` (`user_id`),
  KEY `user_pagina_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `user_pagina_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_pagina_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_pagina`
--

LOCK TABLES `user_pagina` WRITE;
/*!40000 ALTER TABLE `user_pagina` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_pagina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `biografia` text COLLATE utf8mb4_unicode_ci,
  `rol_id` int(10) unsigned DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_nombre_usuario_unique` (`nombre_usuario`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_rol_id_foreign` (`rol_id`),
  CONSTRAINT `users_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `rols` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Colaborador','col@osaw.com','password',NULL,NULL,1,NULL,NULL,NULL,NULL),(2,'Experto','expert@osaw.com','password',NULL,NULL,2,NULL,NULL,NULL,NULL),(3,'Administrador','admin@osaw.com','password',NULL,NULL,3,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vamolas`
--

DROP TABLE IF EXISTS `vamolas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vamolas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vamolas_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `vamolas_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vamolas`
--

LOCK TABLES `vamolas` WRITE;
/*!40000 ALTER TABLE `vamolas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vamolas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waves`
--

DROP TABLE IF EXISTS `waves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `waves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_advertencias` int(11) NOT NULL DEFAULT '0',
  `num_caracteristicas` int(11) NOT NULL DEFAULT '0',
  `num_elem_ARIA` int(11) NOT NULL DEFAULT '0',
  `num_problemas_contraste` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waves_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `waves_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waves`
--

LOCK TABLES `waves` WRITE;
/*!40000 ALTER TABLE `waves` DISABLE KEYS */;
/*!40000 ALTER TABLE `waves` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-29 13:48:01
