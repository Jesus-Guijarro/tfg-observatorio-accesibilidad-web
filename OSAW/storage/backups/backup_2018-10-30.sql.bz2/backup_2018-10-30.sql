-- MySQL dump 10.13  Distrib 8.0.13, for Linux (x86_64)
--
-- Host: localhost    Database: OSAW
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessmonitors`
--

DROP TABLE IF EXISTS `accessmonitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `accessmonitors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aaa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_a` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accessmonitors_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `accessmonitors_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessmonitors`
--

LOCK TABLES `accessmonitors` WRITE;
/*!40000 ALTER TABLE `accessmonitors` DISABLE KEYS */;
INSERT INTO `accessmonitors` VALUES (1,6.90,3,0,0,7,2,1,'/storage/accessmonitor/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,6.90,3,0,0,6,2,1,'/storage/accessmonitor/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,6.90,3,0,0,7,2,1,'/storage/accessmonitor/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,6.90,3,0,0,7,2,1,'/storage/accessmonitor/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,6.90,3,0,0,7,2,1,'/storage/accessmonitor/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,6.90,3,0,0,7,2,1,'/storage/accessmonitor/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,6.90,3,0,0,7,2,1,'/storage/accessmonitor/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,6.90,3,0,0,7,2,1,'/storage/accessmonitor/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(10,7.60,2,0,0,8,2,1,'/storage/accessmonitor/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(12,6.90,3,0,0,7,2,1,'/storage/accessmonitor/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(24,6.10,5,0,1,9,3,2,'/storage/accessmonitor/111_2018-10-30.txt','2018-10-30',111,NULL,NULL),(25,6.40,4,0,1,9,1,1,'/storage/accessmonitor/112_2018-10-30.txt','2018-10-30',112,NULL,NULL),(26,5.50,6,0,1,8,2,1,'/storage/accessmonitor/113_2018-10-30.txt','2018-10-30',113,NULL,NULL),(27,5.10,7,0,2,9,2,1,'/storage/accessmonitor/114_2018-10-30.txt','2018-10-30',114,NULL,NULL),(28,5.40,5,1,1,9,0,1,'/storage/accessmonitor/115_2018-10-30.txt','2018-10-30',115,NULL,NULL),(29,7.60,2,1,0,3,0,0,'/storage/accessmonitor/116_2018-10-30.txt','2018-10-30',116,NULL,NULL),(30,4.90,8,0,2,7,2,1,'/storage/accessmonitor/117_2018-10-30.txt','2018-10-30',117,NULL,NULL),(31,7.60,2,1,0,3,0,0,'/storage/accessmonitor/118_2018-10-30.txt','2018-10-30',118,NULL,NULL),(32,5.30,7,0,1,8,1,1,'/storage/accessmonitor/119_2018-10-30.txt','2018-10-30',119,NULL,NULL),(33,6.00,5,0,1,7,1,1,'/storage/accessmonitor/120_2018-10-30.txt','2018-10-30',120,NULL,NULL);
/*!40000 ALTER TABLE `accessmonitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acheckers`
--

DROP TABLE IF EXISTS `acheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `acheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `acheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `acheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acheckers`
--

LOCK TABLES `acheckers` WRITE;
/*!40000 ALTER TABLE `acheckers` DISABLE KEYS */;
INSERT INTO `acheckers` VALUES (1,2,250,2,0,0,11,7,7,'/storage/achecker/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,2,259,2,0,0,11,7,7,'/storage/achecker/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,2,228,2,0,0,11,7,7,'/storage/achecker/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,2,216,2,0,0,11,7,7,'/storage/achecker/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,2,214,2,0,0,11,7,7,'/storage/achecker/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,2,230,2,0,0,11,7,7,'/storage/achecker/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,2,255,2,0,0,11,7,7,'/storage/achecker/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,2,301,2,0,0,11,7,7,'/storage/achecker/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(10,11,334,2,0,0,11,7,7,'/storage/achecker/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(12,0,0,0,0,0,0,0,0,'/storage/achecker/91_2018-10-30.txt','2018-10-30',91,NULL,NULL),(13,2,233,2,0,0,11,7,7,'/storage/achecker/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(14,0,0,0,0,0,0,0,0,'/storage/achecker/92_2018-10-30.txt','2018-10-30',92,NULL,NULL),(15,0,0,0,0,0,0,0,0,'/storage/achecker/93_2018-10-30.txt','2018-10-30',93,NULL,NULL),(16,0,0,0,0,0,0,0,0,'/storage/achecker/94_2018-10-30.txt','2018-10-30',94,NULL,NULL),(17,0,0,0,0,0,0,0,0,'/storage/achecker/95_2018-10-30.txt','2018-10-30',95,NULL,NULL),(18,0,0,0,0,0,0,0,0,'/storage/achecker/96_2018-10-30.txt','2018-10-30',96,NULL,NULL),(19,0,0,0,0,0,0,0,0,'/storage/achecker/97_2018-10-30.txt','2018-10-30',97,NULL,NULL),(20,0,0,0,0,0,0,0,0,'/storage/achecker/98_2018-10-30.txt','2018-10-30',98,NULL,NULL),(21,0,0,0,0,0,0,0,0,'/storage/achecker/99_2018-10-30.txt','2018-10-30',99,NULL,NULL),(22,0,0,0,0,0,0,0,0,'/storage/achecker/100_2018-10-30.txt','2018-10-30',100,NULL,NULL);
/*!40000 ALTER TABLE `acheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Ministerios y agencias estatales',NULL,NULL),(2,'Entidades autonómicas y locales',NULL,NULL),(3,'Entidades públicas empresariales',NULL,NULL),(4,'Centros universitarios públicos',NULL,NULL),(5,'Empresas privadas',NULL,NULL);
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eiiicheckers`
--

DROP TABLE IF EXISTS `eiiicheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `eiiicheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_aciertos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `eiiicheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `eiiicheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eiiicheckers`
--

LOCK TABLES `eiiicheckers` WRITE;
/*!40000 ALTER TABLE `eiiicheckers` DISABLE KEYS */;
INSERT INTO `eiiicheckers` VALUES (1,83.60,17,314,13,0,'/storage/eiiichecker/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,83.56,17,315,13,0,'/storage/eiiichecker/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,83.70,17,328,13,0,'/storage/eiiichecker/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,83.70,17,321,13,0,'/storage/eiiichecker/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,83.70,17,319,13,0,'/storage/eiiichecker/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,83.70,17,330,13,0,'/storage/eiiichecker/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,83.60,17,324,13,0,'/storage/eiiichecker/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,83.60,17,348,13,0,'/storage/eiiichecker/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(10,84.03,17,470,13,0,'/storage/eiiichecker/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(11,99.10,13,849,13,0,'/storage/eiiichecker/91_2018-10-30.txt','2018-10-30',91,NULL,NULL),(12,83.70,17,349,13,0,'/storage/eiiichecker/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(13,96.18,23,1025,23,0,'/storage/eiiichecker/92_2018-10-30.txt','2018-10-30',92,NULL,NULL),(14,96.18,23,1025,23,0,'/storage/eiiichecker/93_2018-10-30.txt','2018-10-30',93,NULL,NULL),(15,96.18,23,1025,23,0,'/storage/eiiichecker/94_2018-10-30.txt','2018-10-30',94,NULL,NULL),(16,87.96,73,1151,73,0,'/storage/eiiichecker/95_2018-10-30.txt','2018-10-30',95,NULL,NULL),(17,98.75,10,893,10,0,'/storage/eiiichecker/96_2018-10-30.txt','2018-10-30',96,NULL,NULL),(18,99.04,13,859,13,0,'/storage/eiiichecker/97_2018-10-30.txt','2018-10-30',97,NULL,NULL),(19,99.22,16,1126,16,0,'/storage/eiiichecker/98_2018-10-30.txt','2018-10-30',98,NULL,NULL),(20,98.88,15,851,15,0,'/storage/eiiichecker/99_2018-10-30.txt','2018-10-30',99,NULL,NULL),(21,97.73,31,941,31,0,'/storage/eiiichecker/100_2018-10-30.txt','2018-10-30',100,NULL,NULL),(22,95.22,7,315,7,0,'/storage/eiiichecker/161_2018-10-30.txt','2018-10-30',161,NULL,NULL),(23,95.22,7,315,7,0,'/storage/eiiichecker/162_2018-10-30.txt','2018-10-30',162,NULL,NULL),(24,95.21,7,274,7,0,'/storage/eiiichecker/163_2018-10-30.txt','2018-10-30',163,NULL,NULL),(25,95.13,7,234,7,0,'/storage/eiiichecker/164_2018-10-30.txt','2018-10-30',164,NULL,NULL),(26,95.14,7,238,7,0,'/storage/eiiichecker/165_2018-10-30.txt','2018-10-30',165,NULL,NULL),(27,95.14,7,240,7,0,'/storage/eiiichecker/166_2018-10-30.txt','2018-10-30',166,NULL,NULL),(28,95.14,7,237,7,0,'/storage/eiiichecker/167_2018-10-30.txt','2018-10-30',167,NULL,NULL),(29,95.14,7,237,7,0,'/storage/eiiichecker/168_2018-10-30.txt','2018-10-30',168,NULL,NULL),(30,95.13,7,232,7,0,'/storage/eiiichecker/169_2018-10-30.txt','2018-10-30',169,NULL,NULL),(31,95.13,7,232,7,0,'/storage/eiiichecker/170_2018-10-30.txt','2018-10-30',170,NULL,NULL),(42,97.77,26,1535,26,0,'/storage/eiiichecker/111_2018-10-30.txt','2018-10-30',111,NULL,NULL),(43,96.14,8,939,8,0,'/storage/eiiichecker/112_2018-10-30.txt','2018-10-30',112,NULL,NULL),(44,93.91,17,926,17,0,'/storage/eiiichecker/113_2018-10-30.txt','2018-10-30',113,NULL,NULL),(45,85.71,3,360,3,0,'/storage/eiiichecker/114_2018-10-30.txt','2018-10-30',114,NULL,NULL),(46,96.08,9,908,9,0,'/storage/eiiichecker/115_2018-10-30.txt','2018-10-30',115,NULL,NULL),(47,96.30,6,186,6,0,'/storage/eiiichecker/116_2018-10-30.txt','2018-10-30',116,NULL,NULL),(48,92.15,25,917,23,2,'/storage/eiiichecker/117_2018-10-30.txt','2018-10-30',117,NULL,NULL),(49,96.32,6,160,6,0,'/storage/eiiichecker/118_2018-10-30.txt','2018-10-30',118,NULL,NULL),(50,94.79,21,627,21,0,'/storage/eiiichecker/119_2018-10-30.txt','2018-10-30',119,NULL,NULL),(51,93.45,18,868,18,0,'/storage/eiiichecker/120_2018-10-30.txt','2018-10-30',120,NULL,NULL);
/*!40000 ALTER TABLE `eiiicheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1028 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1015,'2018_10_01_211102_create_rols_table',1),(1016,'2018_10_02_000000_create_users_table',1),(1017,'2018_10_02_100000_create_password_resets_table',1),(1018,'2018_10_04_223958_create_categorias_table',1),(1019,'2018_10_05_223735_create_sitios_table',1),(1020,'2018_10_06_223729_create_paginas_table',1),(1021,'2018_10_07_223910_create_user_pagina_table',1),(1022,'2018_10_20_211356_create_accessmonitors_table',1),(1023,'2018_10_20_211408_create_acheckers_table',1),(1024,'2018_10_20_211409_create_eiiicheckers_table',1),(1025,'2018_10_20_211503_create_observatorios_table',1),(1026,'2018_10_20_211509_create_vamolas_table',1),(1027,'2018_10_20_211516_create_waves_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `observatorios`
--

DROP TABLE IF EXISTS `observatorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `observatorios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `porcentaje_comprensible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_operable` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_perceptible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_robusto` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_operable` int(11) NOT NULL DEFAULT '0',
  `num_problemas_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_robusto` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_operable` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_robusto` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `observatorios_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `observatorios_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `observatorios`
--

LOCK TABLES `observatorios` WRITE;
/*!40000 ALTER TABLE `observatorios` DISABLE KEYS */;
INSERT INTO `observatorios` VALUES (1,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(9,75.00,100.00,86.00,66.00,2,0,3,1,2,2,6,0,'/storage/observatorio/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(10,85.00,80.00,76.00,33.00,1,2,6,2,2,2,6,0,'/storage/observatorio/91_2018-10-30.txt','2018-10-30',91,NULL,NULL),(11,75.00,100.00,91.00,50.00,2,0,2,1,2,2,5,0,'/storage/observatorio/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(12,62.00,80.00,74.00,0.00,3,2,7,3,2,2,7,0,'/storage/observatorio/92_2018-10-30.txt','2018-10-30',92,NULL,NULL),(13,62.00,80.00,72.00,0.00,3,2,6,2,2,2,6,0,'/storage/observatorio/95_2018-10-30.txt','2018-10-30',95,NULL,NULL),(14,85.00,70.00,72.00,50.00,1,3,6,1,2,2,6,0,'/storage/observatorio/96_2018-10-30.txt','2018-10-30',96,NULL,NULL),(15,75.00,80.00,77.00,50.00,2,2,5,1,2,2,6,0,'/storage/observatorio/97_2018-10-30.txt','2018-10-30',97,NULL,NULL),(16,75.00,80.00,77.00,50.00,2,2,5,1,2,2,6,0,'/storage/observatorio/98_2018-10-30.txt','2018-10-30',98,NULL,NULL),(17,75.00,80.00,77.00,50.00,2,2,5,1,2,2,6,0,'/storage/observatorio/99_2018-10-30.txt','2018-10-30',99,NULL,NULL),(18,75.00,80.00,77.00,50.00,2,2,5,1,2,2,6,0,'/storage/observatorio/100_2018-10-30.txt','2018-10-30',100,NULL,NULL),(25,75.00,90.00,70.00,50.00,2,1,8,1,2,2,6,0,'/storage/observatorio/111_2018-10-30.txt','2018-10-30',111,NULL,NULL),(26,75.00,90.00,85.00,50.00,2,1,4,1,2,2,6,0,'/storage/observatorio/112_2018-10-30.txt','2018-10-30',112,NULL,NULL),(27,62.00,90.00,76.00,0.00,3,1,6,2,2,2,6,0,'/storage/observatorio/113_2018-10-30.txt','2018-10-30',113,NULL,NULL),(28,62.00,80.00,77.00,0.00,3,2,6,3,2,2,6,0,'/storage/observatorio/117_2018-10-30.txt','2018-10-30',117,NULL,NULL),(29,75.00,90.00,68.00,0.00,2,1,7,2,3,2,5,0,'/storage/observatorio/119_2018-10-30.txt','2018-10-30',119,NULL,NULL),(30,87.00,90.00,69.00,50.00,1,1,8,1,3,2,5,0,'/storage/observatorio/120_2018-10-30.txt','2018-10-30',120,NULL,NULL);
/*!40000 ALTER TABLE `observatorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paginas`
--

DROP TABLE IF EXISTS `paginas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `paginas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `URL` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `archivo_HTML` text COLLATE utf8mb4_unicode_ci,
  `hash` char(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `sitio_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paginas_sitio_id_foreign` (`sitio_id`),
  CONSTRAINT `paginas_sitio_id_foreign` FOREIGN KEY (`sitio_id`) REFERENCES `sitios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paginas`
--

LOCK TABLES `paginas` WRITE;
/*!40000 ALTER TABLE `paginas` DISABLE KEYS */;
INSERT INTO `paginas` VALUES (1,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/inicio',NULL,'default',1,NULL,NULL),(2,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/atencion-ciudadano',NULL,'default',1,NULL,NULL),(3,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/ministerio/funciones-estructura',NULL,'default',1,NULL,NULL),(4,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/ministerio/organismos-entidades',NULL,'default',1,NULL,NULL),(5,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/administracion-justicia/organizacion-justicia',NULL,'default',1,NULL,NULL),(6,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/servicios-ciudadano/tramites-gestiones-personales',NULL,'default',1,NULL,NULL),(7,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/servicios-ciudadano/empleo-publico',NULL,'default',1,NULL,NULL),(8,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/areas-tematicas/registros',NULL,'default',1,NULL,NULL),(9,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/actividad-legislativa/normativa',NULL,'default',1,NULL,NULL),(10,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/justicia-espana/organizacion',NULL,'default',1,NULL,NULL),(11,'https://www.agenciatributaria.es','','default',2,NULL,NULL),(12,'https://www.agenciatributaria.es/AEAT.internet/Renta.shtml',NULL,'default',2,NULL,NULL),(13,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Minimos__reducciones_y_deducciones_en_el_IRPF/Minimos__reducciones_y_deducciones_en_el_IRPF.shtml',NULL,'default',2,NULL,NULL),(14,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Vivienda/Vivienda.shtml',NULL,'default',2,NULL,NULL),(15,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Ciudadanos.shtml',NULL,'default',2,NULL,NULL),(16,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Discapacitados/Discapacitados.shtml',NULL,'default',2,NULL,NULL),(17,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Tramites_electronicos/Tramites_electronicos.shtml',NULL,'default',2,NULL,NULL),(18,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Certificados_tributarios/Certificados_tributarios.shtml',NULL,'default',2,NULL,NULL),(19,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Limitacion_de_pagos_en_efectivo/Limitacion_de_pagos_en_efectivo.shtml',NULL,'default',2,NULL,NULL),(20,'https://www.agenciatributaria.es/AEAT.internet/Inicio/La_Agencia_Tributaria/Campanas/Censos__NIF_y_domicilio_fiscal/Ciudadanos/Ciudadanos.shtml',NULL,'default',2,NULL,NULL),(21,'http://www.gva.es/es/inicio/presentacion','/storage/paginas/21.html','aaf69dae0c6f8e22',3,NULL,NULL),(22,'http://www.gva.es/es/inicio/administraciones','/storage/paginas/22.html','8a3458ee6a6cd0bc',3,NULL,NULL),(23,'http://www.gva.es/es/inicio/ciudadanos','/storage/paginas/23.html','0b80f02cf422150b',3,NULL,NULL),(24,'http://www.gva.es/es/inicio/ciudadanos/ciu_busco_trabajo','/storage/paginas/24.html','39dfbe3db09a9c55',3,NULL,NULL),(25,'http://www.gva.es/es/inicio/ciudadanos/ciu_quiero_acceder_a_una_vivienda','/storage/paginas/25.html','7eed3b8c35030e8e',3,NULL,NULL),(26,'http://www.gva.es/es/inicio/ciudadanos/ciu_quiero_estudiar_y_formarme','/storage/paginas/26.html','87dda9735b69609f',3,NULL,NULL),(27,'http://www.gva.es/es/inicio/ciudadanos/ciu_necesito_ir_al_medico','/storage/paginas/27.html','7ed48e7d91b1c0e8',3,NULL,NULL),(28,'http://www.gva.es/es/inicio/ciudadanos/ciu_necesito_informacion_tributaria','/storage/paginas/28.html','15e5dfe147baadad',3,NULL,NULL),(29,'http://www.gva.es/es/inicio/administraciones/adm_tramites_y_servicios','/storage/paginas/29.html','779ab76b71652199',3,NULL,NULL),(30,'http://www.gva.es/es/inicio/administraciones/adm_ayudas_y_subvenciones','/storage/paginas/30.html','1abae9a76e8d947f',3,NULL,NULL),(31,'http://www.alicante.es/es',NULL,'default',4,NULL,NULL),(32,'http://www.alicante.es/es/contenidos/servicios-emergencia',NULL,'default',4,NULL,NULL),(33,'http://www.alicante.es/es/area-tematica/servicio-de-atencion-integral-a-la-ciudadania---saic',NULL,'default',4,NULL,NULL),(34,'http://www.alicante.es/es/contenidos/ciudad-alicante',NULL,'default',4,NULL,NULL),(35,'http://www.alicante.es/es/galerias_imagen',NULL,'default',4,NULL,NULL),(36,'http://www.alicante.es/es/area-tematica/turismo',NULL,'default',4,NULL,NULL),(37,'http://www.alicante.es/es/noticias/actualizacion-del-espacio-participacion-ciudadana',NULL,'default',4,NULL,NULL),(38,'http://www.alicante.es/es/contenidos/transporte-alicante-metropolitano-tam',NULL,'default',4,NULL,NULL),(39,'http://www.alicante.es/es/area-tematica/seguridad-ciudadana',NULL,'default',4,NULL,NULL),(40,'http://www.alicante.es/es/area-tematica/comercio-consumo-sanidad',NULL,'default',4,NULL,NULL),(41,'http://www.renfe.com',NULL,'default',5,NULL,NULL),(42,'http://www.renfe.com/empresa/atencion_cliente/index.html',NULL,'default',5,NULL,NULL),(43,'http://www.renfe.com/viajeros/atendo/index.html',NULL,'default',5,NULL,NULL),(44,'http://www.renfe.com/empresa/comunicacion/incidencias.html',NULL,'default',5,NULL,NULL),(45,'http://www.renfe.com/viajeros/atendo/estaciones.html',NULL,'default',5,NULL,NULL),(46,'http://www.renfe.com/viajeros/info/index.html',NULL,'default',5,NULL,NULL),(47,'http://www.renfe.com/viajeros/tarifas/index.html',NULL,'default',5,NULL,NULL),(48,'http://www.renfe.com/viajeros/atendo/informacion_cliente.html',NULL,'default',5,NULL,NULL),(49,'http://www.renfe.com/viajeros/movilidad/index.html',NULL,'default',5,NULL,NULL),(50,'http://www.renfe.com/viajeros/cercanias/index.html',NULL,'default',5,NULL,NULL),(51,'https://www.cdti.es',NULL,'default',6,NULL,NULL),(52,'https://www.cdti.es/index.asp?MP=6&MS=5&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(53,'https://www.cdti.es/index.asp?MP=100&MS=802&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(54,'https://www.cdti.es/index.asp?MP=8&MS=128&MN=2&r=1536*864',NULL,'default',6,NULL,NULL),(55,'https://www.cdti.es/index.asp?MP=101&MS=821&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(56,'https://www.cdti.es/index.asp?MP=8&MS=69&MN=2&r=1536*864',NULL,'default',6,NULL,NULL),(57,'https://www.cdti.es/index.asp?MP=8&MS=129&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(58,'https://www.cdti.es/index.asp?MP=9&MS=31&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(59,'https://www.cdti.es/index.asp?MP=99&MS=0&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(60,'https://www.cdti.es/index.asp?MP=20&MS=0&MN=1',NULL,'default',6,NULL,NULL),(61,'https://www.upv.es',NULL,'default',7,NULL,NULL),(62,'https://www.upv.es/perfiles/futuro-alumno/index-es.html',NULL,'default',7,NULL,NULL),(63,'https://www.upv.es/admision/empezar-en-la-universidad/index-es.html',NULL,'default',7,NULL,NULL),(64,'https://www.upv.es/admision/traslados-e-intercambios/index-es.html',NULL,'default',7,NULL,NULL),(65,'https://www.upv.es/estudios/grado/index-es.html',NULL,'default',7,NULL,NULL),(66,'https://www.upv.es/estudios/aula-abierta/index-es.html',NULL,'default',7,NULL,NULL),(67,'https://www.upv.es/investigacion/estructuras/index-es.html',NULL,'default',7,NULL,NULL),(68,'https://www.upv.es/investigacion/iniciativas-idi/index-es.html',NULL,'default',7,NULL,NULL),(69,'https://www.upv.es/organizacion/escuelas-facultades/index-es.html',NULL,'default',7,NULL,NULL),(70,'https://www.upv.es/organizacion/departamentos/index-es.html',NULL,'default',7,NULL,NULL),(71,'https://www.ua.es/es/',NULL,'default',8,NULL,NULL),(72,'https://web.ua.es/es/estudia-en-la-ua.html',NULL,'default',8,NULL,NULL),(73,'https://web.ua.es/es/orientacion-y-empleo.html',NULL,'default',8,NULL,NULL),(74,'https://web.ua.es/es/grados-oficiales.html',NULL,'default',8,NULL,NULL),(75,'https://web.ua.es/es/masteres-oficiales.html',NULL,'default',8,NULL,NULL),(76,'https://web.ua.es/es/investiga-en-la-ua.html',NULL,'default',8,NULL,NULL),(77,'https://web.ua.es/es/movilidad.html',NULL,'default',8,NULL,NULL),(78,'https://web.ua.es/es/centros-departamentos-e-institutos.html',NULL,'default',8,NULL,NULL),(79,'https://web.ua.es/es/recursos-universitarios.html',NULL,'default',8,NULL,NULL),(80,'https://web.ua.es/es/centro-de-apoyo-al-estudiante.html',NULL,'default',8,NULL,NULL),(81,'https://www.endesaclientes.com',NULL,'default',9,NULL,NULL),(82,'https://www.endesaclientes.com/hogares/atencion-cliente.html',NULL,'default',9,NULL,NULL),(83,'https://www.endesaclientes.com/facturas-lecturas',NULL,'default',9,NULL,NULL),(84,'https://www.endesaclientes.com/facturas-lecturas/ver-factura',NULL,'default',9,NULL,NULL),(85,'https://www.endesaclientes.com/facturas-lecturas/pagar-facturas',NULL,'default',9,NULL,NULL),(86,'https://www.endesaclientes.com/facturas-lecturas/dar-lectura',NULL,'default',9,NULL,NULL),(87,'https://www.endesaclientes.com/explicacion-factura.html',NULL,'default',9,NULL,NULL),(88,'https://www.endesaclientes.com/factura-electronica.html',NULL,'default',9,NULL,NULL),(89,'https://www.endesaclientes.com/hogares/mantenimiento.html',NULL,'default',9,NULL,NULL),(90,'https://www.endesaclientes.com/gestiones-contratos',NULL,'default',9,NULL,NULL),(91,'https://www.iberdrola.es','/storage/paginas/91.html','d82407a2d77a1f53',10,NULL,NULL),(92,'https://www.iberdrola.es/atencion-cliente','/storage/paginas/92.html','9c4ea58453a76cfc',10,NULL,NULL),(93,'https://www.iberdrola.es/atencion-cliente#form-consultas','/storage/paginas/93.html','6f8b2f86c30a352d',10,NULL,NULL),(94,'https://www.iberdrola.es/atencion-cliente#panel-extranjero','/storage/paginas/94.html','3f77a007b109359b',10,NULL,NULL),(95,'https://www.iberdrola.es/ahorrar-energia/calcular-potencia-electrica-optima','/storage/paginas/95.html','2670ebdd731a4216',10,NULL,NULL),(96,'https://www.iberdrola.es/informacion/facturas','/storage/paginas/96.html','7b400515c8b2ad55',10,NULL,NULL),(97,'https://www.iberdrola.es/informacion/alta-nuevo-suministro-electrico','/storage/paginas/97.html','13be7f2eca543525',10,NULL,NULL),(98,'https://www.iberdrola.es/informacion/instalacion-electricidad','/storage/paginas/98.html','f064bde0a17c8d10',10,NULL,NULL),(99,'https://www.iberdrola.es/informacion/instalacion-gas','/storage/paginas/99.html','17065fbd47ba34b2',10,NULL,NULL),(100,'https://www.iberdrola.es/informacion/alta-nuevo-suministro-gas','/storage/paginas/100.html','d7e4c7254a020878',10,NULL,NULL),(101,'https://www.bancosantander.es/es/particulares',NULL,'default',23,NULL,NULL),(102,'https://www.bancosantander.es/es/particulares/prestamos',NULL,'default',23,NULL,NULL),(103,'https://www.bancosantander.es/es/particulares/cuentas-y-tarjetas',NULL,'default',23,NULL,NULL),(104,'https://www.bancosantander.es/es/particulares/ahorro-e-inversion',NULL,'default',23,NULL,NULL),(105,'https://www.bancosantander.es/es/particulares/hipotecas',NULL,'default',23,NULL,NULL),(106,'https://www.bancosantander.es/es/particulares/prestamos',NULL,'default',23,NULL,NULL),(107,'https://www.bancosantander.es/es/particulares/banca-online',NULL,'default',23,NULL,NULL),(108,'https://www.bancosantander.es/es/particulares/hazte-cliente',NULL,'default',23,NULL,NULL),(109,'https://www.bancosantander.es/es/particulares/banca-online/clave-online',NULL,'default',23,NULL,NULL),(110,'https://www.bancosantander.es/es/particulares/banca-online/internet',NULL,'default',23,NULL,NULL),(111,'https://www.iberia.com','/storage/paginas/111.html','6faf26d00e3b7d21',24,NULL,NULL),(112,'https://www.iberia.com/es/buscador-vuelos/','/storage/paginas/112.html','0ef6dedfc85fae9e',24,NULL,NULL),(113,'https://www.iberia.com/es/puente-aereo/','/storage/paginas/113.html','c7b3255cc67ed0c3',24,NULL,NULL),(114,'https://www.iberia.com/es/vuelo+hotel/','/storage/paginas/114.html','9727ac90bcbb0d69',24,NULL,NULL),(115,'https://www.iberia.com/es/atencion-al-cliente/#','/storage/paginas/115.html','7ae1848e2e06937b',24,NULL,NULL),(116,'https://www.iberia.com/es/autocheckin-online/?language=es&market=es#/ibcose','/storage/paginas/116.html','842c7f57db11b35d',24,NULL,NULL),(117,'https://www.iberia.com/es/informacion-checkin/','/storage/paginas/117.html','bbda6172f180eba0',24,NULL,NULL),(118,'https://www.iberia.com/es/gestion-de-reservas/?language=es&market=es&channel=COM#!/chktrp','/storage/paginas/118.html','b2cfbc1e7e492531',24,NULL,NULL),(119,'https://www.iberia.com/es/facturas/','/storage/paginas/119.html','ceeb9285348308ff',24,NULL,NULL),(120,'https://www.iberia.com/es/horarios/','/storage/paginas/120.html','fcd01a946f67a2a8',24,NULL,NULL),(121,'http://www.mscbs.gob.es/#',NULL,'default',11,NULL,NULL),(122,'http://www.mscbs.gob.es/#aldia-sanidad',NULL,'default',11,NULL,NULL),(123,'http://www.mscbs.gob.es/#aldia-servicios',NULL,'default',11,NULL,NULL),(124,'http://www.mscbs.gob.es/#fotos',NULL,'default',11,NULL,NULL),(125,'http://www.mscbs.gob.es/#videos',NULL,'default',11,NULL,NULL),(126,'http://www.mscbs.gob.es/accesibilidad/home.htm',NULL,'default',11,NULL,NULL),(127,'http://www.mscbs.gob.es/avisoLegal/home.htm',NULL,'default',11,NULL,NULL),(128,'http://www.mscbs.gob.es/avisoLegal/home.htm#politicaCookie',NULL,'default',11,NULL,NULL),(129,'http://www.mscbs.gob.es/biblioPublic/biblioDocum/home.htm',NULL,'default',11,NULL,NULL),(130,'http://www.mscbs.gob.es/biblioPublic/portada/home.htm',NULL,'default',11,NULL,NULL),(131,'http://www.ciencia.gob.es',NULL,'default',12,NULL,NULL),(132,'http://www.ciencia.gob.es/#',NULL,'default',12,NULL,NULL),(133,'http://www.ciencia.gob.es/#abre',NULL,'default',12,NULL,NULL),(134,'http://www.ciencia.gob.es/#tab1',NULL,'default',12,NULL,NULL),(135,'http://www.ciencia.gob.es/portal/site/MICINN/contacto',NULL,'default',12,NULL,NULL),(136,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.00d7c011ca2a3753222b7d1001432ea0/?vgnextoid=33881f4368aef110VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(137,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.00d7c011ca2a3753222b7d1001432ea0/?vgnextoid=f4c81f4368aef110VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(138,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=0b6ac76c760d4610VgnVCM1000001d04140aRCRD',NULL,'default',12,NULL,NULL),(139,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=25c55ef3677c4610VgnVCM1000001d04140aRCRD',NULL,'default',12,NULL,NULL),(140,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=f0c992106a8a3210VgnVCM1000001034e20aRCRD&vgnextchannel=f0c992106a8a3210VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(141,'http://www.mecd.gob.es/portada-mecd/',NULL,'default',13,NULL,NULL),(142,'http://www.mecd.gob.es/aviso-legal-mecd/',NULL,'default',13,NULL,NULL),(143,'http://www.mecd.gob.es/cultura-mecd/',NULL,'default',13,NULL,NULL),(144,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/archivos.html',NULL,'default',13,NULL,NULL),(145,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/artesescenicas.html',NULL,'default',13,NULL,NULL),(146,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/bibliotecas.html',NULL,'default',13,NULL,NULL),(147,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/cine.html',NULL,'default',13,NULL,NULL),(148,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/cooperacion.html',NULL,'default',13,NULL,NULL),(149,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/industriasculturales.html',NULL,'default',13,NULL,NULL),(150,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/libro.html',NULL,'default',13,NULL,NULL),(151,'https://www.aemps.gob.es/laAEMPS/portada/home.htm',NULL,'default',15,NULL,NULL),(152,'https://www.aemps.gob.es/avisoLegal/home.htm',NULL,'default',15,NULL,NULL),(153,'https://www.aemps.gob.es/accesibilidad/home.htm',NULL,'default',15,NULL,NULL),(154,'https://www.aemps.gob.es/ca/home.htm',NULL,'default',15,NULL,NULL),(155,'https://www.aemps.gob.es/cosmeticosHigiene/portada/home.htm',NULL,'default',15,NULL,NULL),(156,'https://www.aemps.gob.es/en/home.htm',NULL,'default',15,NULL,NULL),(157,'https://www.aemps.gob.es/eu/home.htm',NULL,'default',15,NULL,NULL),(158,'https://www.aemps.gob.es/gl/home.htm',NULL,'default',15,NULL,NULL),(159,'https://www.aemps.gob.es/guiaNav/home.htm',NULL,'default',15,NULL,NULL),(160,'https://www.aemps.gob.es/home.htm',NULL,'default',15,NULL,NULL),(161,'http://www.raspeig.es/','/storage/paginas/161.html','3e17401f3f90f648',17,NULL,NULL),(162,'http://www.raspeig.es/#','/storage/paginas/162.html','ccb6fc772cdb690b',17,NULL,NULL),(163,'http://www.raspeig.es/actualidad/','/storage/paginas/163.html','7e3b7906b2e8832f',17,NULL,NULL),(164,'http://www.raspeig.es/actualidad/arranca-en-las-calles-vicente-savall-y-alfonso-xiii-el-nuevo-plan-de-poda-de-ciudad/','/storage/paginas/164.html','92dde47d274f23c9',17,NULL,NULL),(165,'http://www.raspeig.es/actualidad/bicisanvi-incorpora-30-unidades-con-marchas-y-luces/','/storage/paginas/165.html','73486a4c54b5eccb',17,NULL,NULL),(166,'http://www.raspeig.es/actualidad/brillante-cierre-del-mig-any-con-el-concierto-de-l-associacio-musical-l-avanc-y-la-entrega-de-los-premios-de-bandas-y-collas-2018/','/storage/paginas/166.html','ea707fbe3b4ceb89',17,NULL,NULL),(167,'http://www.raspeig.es/actualidad/comercio-entre-calles-el-viernes-2-de-noviembre/','/storage/paginas/167.html','9d5a3d56542f0f5f',17,NULL,NULL),(168,'http://www.raspeig.es/actualidad/comercio-entre-calles-queda-aplazado-ante-la-prevision-de-chubascos/','/storage/paginas/168.html','812d3087e28727ca',17,NULL,NULL),(169,'http://www.raspeig.es/actualidad/el-ayuntamiento-lanza-una-nueva-oferta-publica-de-viviendas-con-finalidad-social/','/storage/paginas/169.html','764045f36dd785d7',17,NULL,NULL),(170,'http://www.raspeig.es/actualidad/la-nueva-ordenanza-de-animales-de-compania-ampara-la-regulacion-de-las-colonias-felinas/','/storage/paginas/170.html','3dc44649059da9f9',17,NULL,NULL),(171,'http://www.valencia.es/',NULL,'default',18,NULL,NULL),(172,'http://www.valencia.es/Contratacion/pdc_Fallera.nsf/fCategoriaVistaExpedientes?readForm&Vista=vLicitaciones_encurso&Categoria=Servicio%20de%20Contrataci%F3n&titulo=Licitaciones%20en%20curso&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(173,'http://www.valencia.es/Contratacion/pdc_universidad.nsf/fCategoriaVistaExpedientes?readForm&Vista=vLicitaciones_encursov&Categoria=Servici%20de%20Contractaci%F3&titulo=Licitacions%20en%20curs&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(174,'http://www.valencia.es/agenciabici/va',NULL,'default',18,NULL,NULL),(175,'http://www.valencia.es/ayuntamiento/AInstitucional.nsf/fCategoriaVista2?readForm&nivel=8&Vista=vActivAIWv&Categoria=Actividades&lang=2&expand=2&nivelExpandido=1.1.1&bdorigen=ayuntamiento/ayuntamiento.nsf',NULL,'default',18,NULL,NULL),(176,'http://www.valencia.es/ayuntamiento/ConsejosDisAct.nsf/fCategoriaVista2?readForm&Vista=vComisionesTodasVal&Categoria=Consejos&lang=2&nivel=3%5f5&nivelExpandido=1&bdorigen=ayuntamiento/ayuntamiento.nsf&idapoyo=9A0B3E8F6AB1CDBAC12582410042C735',NULL,'default',18,NULL,NULL),(177,'http://www.valencia.es/ayuntamiento/Mercados.nsf/vDocumentosTituloAux/Inicio?opendocument&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(178,'http://www.valencia.es/ayuntamiento/OMIDC.nsf/vDocumentosTituloAux/Inicio?opendocument&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(179,'http://www.valencia.es/ayuntamiento/WebCiudano.nsf/Registro?ReadForm&lang=2&id=0F3E93B421616BDEC1257F46002D260A&estado=0&nivel=2_2&bdorigen=ayuntamiento/ayuntamiento.nsf',NULL,'default',18,NULL,NULL),(180,'http://www.valencia.es/ayuntamiento/agenda_accesible.nsf/Agenda/001E7DF55397BF5DC125830100429CBA?OpenDocument&lang=2&nivel=4&bdOrigen=ayuntamiento/laciudad.nsf',NULL,'default',18,NULL,NULL),(181,'http://www.idae.es/',NULL,'default',19,NULL,NULL),(182,'http://www.idae.es/#',NULL,'default',19,NULL,NULL),(183,'http://www.idae.es/#main-content',NULL,'default',19,NULL,NULL),(184,'http://www.idae.es/accesibilidad-wai-aa',NULL,'default',19,NULL,NULL),(185,'http://www.idae.es/ahorra-energia',NULL,'default',19,NULL,NULL),(186,'http://www.idae.es/ahorra-energia/aula-digital-aprende-ahorrar-energia',NULL,'default',19,NULL,NULL),(187,'http://www.idae.es/ahorra-energia/campanas-y-acciones-de-acompanamiento',NULL,'default',19,NULL,NULL),(188,'http://www.idae.es/ahorra-energia/nuevo-reglamento-para-el-etiquetado-energetico',NULL,'default',19,NULL,NULL),(189,'http://www.idae.es/ahorra-energia/renovables-de-uso-domestico/programa-biomcasa-ii',NULL,'default',19,NULL,NULL),(190,'http://www.idae.es/ahorra-energia/renovables-de-uso-domestico/programa-geotcasa',NULL,'default',19,NULL,NULL),(191,'http://www.umh.es/#',NULL,'default',21,NULL,NULL),(192,'http://www.umh.es/?lang=EN',NULL,'default',21,NULL,NULL),(193,'http://www.umh.es/?lang=ES',NULL,'default',21,NULL,NULL),(194,'http://www.umh.es/?lang=VAL',NULL,'default',21,NULL,NULL),(195,'http://www.umh.es/acc/',NULL,'default',21,NULL,NULL),(196,'http://www.umh.es/contenido/AdmisionAyudas/:admision_ayudas/datos_es.html',NULL,'default',21,NULL,NULL),(197,'http://www.umh.es/contenido/Alumni/:none/datos_es.html',NULL,'default',21,NULL,NULL),(198,'http://www.umh.es/contenido/Alumni/:utilidades_alumni/datos_es.html',NULL,'default',21,NULL,NULL),(199,'http://www.umh.es/contenido/Estudiantes/:CEGECA/datos_es.html',NULL,'default',21,NULL,NULL),(200,'http://www.umh.es/contenido/Estudiantes/:Curso_Adaptacion_Grado/datos_es.html',NULL,'default',21,NULL,NULL),(201,'https://www.uv.es/#',NULL,'default',22,NULL,NULL),(202,'https://www.uv.es/#home',NULL,'default',22,NULL,NULL),(203,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/1-escull-master.html',NULL,'default',22,NULL,NULL),(204,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/2-lliura-documentacio.html',NULL,'default',22,NULL,NULL),(205,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/3-espera-notificacio-admissio-max-24h-.html',NULL,'default',22,NULL,NULL),(206,'https://www.uv.es/master-ultimes-places/ca/masters-oficials.html',NULL,'default',22,NULL,NULL),(207,'https://www.uv.es/master-ultimes-places/ca/normativa-basica/normativa-basica.html',NULL,'default',22,NULL,NULL),(208,'https://www.uv.es/recull',NULL,'default',22,NULL,NULL),(209,'https://www.uv.es/uvnoticies',NULL,'default',22,NULL,NULL),(210,'https://www.uv.es/uvweb/college/en/university-valencia-1285845048380.html',NULL,'default',22,NULL,NULL),(211,'http://www.mitramiss.gob.es/#',NULL,'default',14,NULL,NULL),(212,'http://www.mitramiss.gob.es/ca/index.htm',NULL,'default',14,NULL,NULL),(213,'http://www.mitramiss.gob.es/cartaespana/index.htm',NULL,'default',14,NULL,NULL),(214,'http://www.mitramiss.gob.es/en/index.htm',NULL,'default',14,NULL,NULL),(215,'http://www.mitramiss.gob.es/es/Guia/texto/index.htm',NULL,'default',14,NULL,NULL),(216,'http://www.mitramiss.gob.es/es/contacto_ministerio/index.htm',NULL,'default',14,NULL,NULL),(217,'http://www.mitramiss.gob.es/es/el_ministerio/index.htm',NULL,'default',14,NULL,NULL),(218,'http://www.mitramiss.gob.es/es/estadisticas/index.htm',NULL,'default',14,NULL,NULL),(219,'http://www.mitramiss.gob.es/es/extras/accesibilidad.htm',NULL,'default',14,NULL,NULL),(220,'http://www.mitramiss.gob.es/es/extras/avisolegal.htm',NULL,'default',14,NULL,NULL),(221,'http://www.aemet.es/ca/portada',NULL,'default',16,NULL,NULL),(222,'http://www.aemet.es/en/portada',NULL,'default',16,NULL,NULL),(223,'http://www.aemet.es/es/accesibilidad',NULL,'default',16,NULL,NULL),(224,'http://www.aemet.es/es/app/eltiempodeAEMET',NULL,'default',16,NULL,NULL),(225,'http://www.aemet.es/es/ayuda',NULL,'default',16,NULL,NULL),(226,'http://www.aemet.es/es/conocenos',NULL,'default',16,NULL,NULL),(227,'http://www.aemet.es/es/conocenos/a_que_nos_dedicamos',NULL,'default',16,NULL,NULL),(228,'http://www.aemet.es/es/conocenos/colaboracion_institucional/convenios',NULL,'default',16,NULL,NULL),(229,'http://www.aemet.es/es/conocenos/congresos_y_conferencias',NULL,'default',16,NULL,NULL),(230,'http://www.aemet.es/es/conocenos/congresos_y_conferencias/congresos',NULL,'default',16,NULL,NULL),(231,'https://www.icex.es/icex/es/',NULL,'default',20,NULL,NULL),(232,'https://www.icex.es/icex/es/Navegacion-zona-contacto/libreria-icex/index.html',NULL,'default',20,NULL,NULL),(233,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/empresas/index.html',NULL,'default',20,NULL,NULL),(234,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/en-cifras/index.html',NULL,'default',20,NULL,NULL),(235,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/index.html',NULL,'default',20,NULL,NULL),(236,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/invertir/index.html',NULL,'default',20,NULL,NULL),(237,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/mercados/index.html',NULL,'default',20,NULL,NULL),(238,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/mundo/index.html',NULL,'default',20,NULL,NULL),(239,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/noticias/index.html',NULL,'default',20,NULL,NULL),(240,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/observatorio2/index.html',NULL,'default',20,NULL,NULL);
/*!40000 ALTER TABLE `paginas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rols`
--

DROP TABLE IF EXISTS `rols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `rols` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rols`
--

LOCK TABLES `rols` WRITE;
/*!40000 ALTER TABLE `rols` DISABLE KEYS */;
INSERT INTO `rols` VALUES (1,'Colaborador',NULL,NULL),(2,'Experto',NULL,NULL),(3,'Administrador',NULL,NULL);
/*!40000 ALTER TABLE `rols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitios`
--

DROP TABLE IF EXISTS `sitios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sitios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dominio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodicidad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia` int(11) NOT NULL,
  `automatizado` tinyint(1) NOT NULL,
  `num_paginas` int(11) NOT NULL,
  `herramientas` json NOT NULL,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitios_nombre_unique` (`nombre`),
  KEY `sitios_categoria_id_foreign` (`categoria_id`),
  CONSTRAINT `sitios_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitios`
--

LOCK TABLES `sitios` WRITE;
/*!40000 ALTER TABLE `sitios` DISABLE KEYS */;
INSERT INTO `sitios` VALUES (1,'Ministerio de Justicia','www.mjusticia.gob.es','Semanal','13:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL),(2,'Agencia Estatal de Administración Tributaria','www.agenciatributaria.es','Semanal','13:00',1,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL),(3,'Generalitat Valenciana','www.gva.es','Semanal','13:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',2,NULL,NULL),(4,'Ayuntamiento de Alicante','www.alicante.es','Semanal','13:00',3,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',2,NULL,NULL),(5,'Red Nacional de los Ferrocarriles Españoles (RENFE)','www.renfe.com','Semanal','13:00',4,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(6,'Centro para el Desarrollo Tecnológico Industrial (CDTI)','www.cdti.es','Semanal','13:00',5,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(7,'Universitat Politècnica de València (UPV)','www.upv.es','Semanal','13:00',6,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',4,NULL,NULL),(8,'Universidad de Alicante (UA)','web.ua.es','Semanal','14:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',4,NULL,NULL),(9,'Endesa','/www.endesaclientes.com','Semanal','14:00',1,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(10,'Iberdrola','www.iberdrola.es','Semanal','14:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(11,'Ministerio de Sanidad, Consumo y Bienestar Social','www.mscbs.gob.es','Semanal','14:00',3,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(12,'Ministerio de Ciencia, Innovación y Universidades','www.ciencia.gob.es','Semanal','14:00',4,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(13,'Ministerio de Educación, Cultura y Deporte','www.mecd.gob.es','Semanal','14:00',5,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(14,'Ministerio de Trabajo, Migraciones y Seguridad Social','www.mitramiss.gob.es','Semanal','14:00',6,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(15,'Agencia Española de Medicamentos y Productos Sanitarios','www.aemps.gob.es','Semanal','15:00',0,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(16,'Agencia Estatal de Meterología','www.aemet.es','Semanal','15:00',1,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(17,'Ayuntamiento de San Vicente del Raspeig','www.raspeig.es','Semanal','15:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": false, \"accessmonitor\": false}',2,NULL,NULL),(18,'Ayuntamiento de Valencia','www.valencia.es','Semanal','15:00',3,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": false, \"accessmonitor\": false}',2,NULL,NULL),(19,'Instituto para la Diversificación y Ahorro de la Energía (IDAE)','www.idae.es','Semanal','15:00',4,1,10,'{\"wave\": false, \"vamola\": false, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(20,'Instituto Español de Comercio Exterior (ICEX)','www.icex.es','Semanal','15:00',5,1,10,'{\"wave\": false, \"vamola\": false, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(21,'Universidad Miguel Hernández (UMH)','www.umh.es','Semanal','15:00',6,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": false, \"observatorio\": false, \"accessmonitor\": true}',4,NULL,NULL),(22,'Universitat de València (UV)','www.uv.es','Semanal','16:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": false, \"observatorio\": false, \"accessmonitor\": true}',4,NULL,NULL),(23,'Banco Santander','www.bancosantander.es','Semanal','16:00',1,1,10,'{\"wave\": false, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(24,'Iberia','www.iberia.com','Semanal','16:00',2,1,10,'{\"wave\": false, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL);
/*!40000 ALTER TABLE `sitios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_pagina`
--

DROP TABLE IF EXISTS `user_pagina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user_pagina` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `informe` json NOT NULL,
  `fecha_test` date NOT NULL,
  `revisado` tinyint(1) NOT NULL,
  `porcentaje_perceptible` double(8,2) NOT NULL,
  `porcentaje_operable` double(8,2) NOT NULL,
  `porcentaje_comprensible` double(8,2) NOT NULL,
  `porcentaje_robusto` double(8,2) NOT NULL,
  `num_errores_a` int(11) NOT NULL,
  `num_errores_aa` int(11) NOT NULL,
  `num_errores_aaa` int(11) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_pagina_user_id_foreign` (`user_id`),
  KEY `user_pagina_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `user_pagina_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_pagina_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_pagina`
--

LOCK TABLES `user_pagina` WRITE;
/*!40000 ALTER TABLE `user_pagina` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_pagina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `biografia` text COLLATE utf8mb4_unicode_ci,
  `rol_id` int(10) unsigned DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_nombre_unique` (`nombre`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_rol_id_foreign` (`rol_id`),
  CONSTRAINT `users_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `rols` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Colaborador','col@osaw.com','password',NULL,NULL,1,NULL,NULL,NULL,NULL),(2,'Experto','expert@osaw.com','password',NULL,NULL,2,NULL,NULL,NULL,NULL),(3,'Administrador','admin@osaw.com','password',NULL,NULL,3,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vamolas`
--

DROP TABLE IF EXISTS `vamolas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vamolas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vamolas_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `vamolas_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vamolas`
--

LOCK TABLES `vamolas` WRITE;
/*!40000 ALTER TABLE `vamolas` DISABLE KEYS */;
INSERT INTO `vamolas` VALUES (1,2,191,2,0,0,11,7,8,'/storage/vamola/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,2,195,2,0,0,11,7,8,'/storage/vamola/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,2,173,2,0,0,11,7,8,'/storage/vamola/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,2,159,2,0,0,11,7,8,'/storage/vamola/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,2,158,2,0,0,11,7,8,'/storage/vamola/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,2,174,2,0,0,11,7,8,'/storage/vamola/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,2,194,2,0,0,11,7,8,'/storage/vamola/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,2,232,2,0,0,11,7,8,'/storage/vamola/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(9,11,252,2,0,0,11,8,8,'/storage/vamola/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(10,0,0,0,0,0,0,0,0,'/storage/vamola/91_2018-10-30.txt','2018-10-30',91,NULL,NULL),(11,2,170,2,0,0,11,7,8,'/storage/vamola/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(12,0,0,0,0,0,0,0,0,'/storage/vamola/92_2018-10-30.txt','2018-10-30',92,NULL,NULL),(13,0,0,0,0,0,0,0,0,'/storage/vamola/93_2018-10-30.txt','2018-10-30',93,NULL,NULL),(14,0,0,0,0,0,0,0,0,'/storage/vamola/94_2018-10-30.txt','2018-10-30',94,NULL,NULL),(15,0,0,0,0,0,0,0,0,'/storage/vamola/95_2018-10-30.txt','2018-10-30',95,NULL,NULL),(16,0,0,0,0,0,0,0,0,'/storage/vamola/96_2018-10-30.txt','2018-10-30',96,NULL,NULL),(17,0,0,0,0,0,0,0,0,'/storage/vamola/97_2018-10-30.txt','2018-10-30',97,NULL,NULL),(18,0,0,0,0,0,0,0,0,'/storage/vamola/98_2018-10-30.txt','2018-10-30',98,NULL,NULL),(19,0,0,0,0,0,0,0,0,'/storage/vamola/99_2018-10-30.txt','2018-10-30',99,NULL,NULL),(20,0,0,0,0,0,0,0,0,'/storage/vamola/100_2018-10-30.txt','2018-10-30',100,NULL,NULL),(21,5,343,3,0,0,11,7,8,'/storage/vamola/161_2018-10-30.txt','2018-10-30',161,NULL,NULL),(22,5,343,3,0,0,11,7,8,'/storage/vamola/162_2018-10-30.txt','2018-10-30',162,NULL,NULL),(23,5,231,3,0,0,12,7,8,'/storage/vamola/163_2018-10-30.txt','2018-10-30',163,NULL,NULL),(24,5,164,3,0,0,12,7,8,'/storage/vamola/164_2018-10-30.txt','2018-10-30',164,NULL,NULL),(25,5,171,3,0,0,12,7,8,'/storage/vamola/165_2018-10-30.txt','2018-10-30',165,NULL,NULL),(26,5,183,3,0,0,12,7,8,'/storage/vamola/166_2018-10-30.txt','2018-10-30',166,NULL,NULL),(27,5,169,3,0,0,11,7,8,'/storage/vamola/167_2018-10-30.txt','2018-10-30',167,NULL,NULL),(28,5,169,3,0,0,11,7,8,'/storage/vamola/168_2018-10-30.txt','2018-10-30',168,NULL,NULL),(29,5,163,3,0,0,11,7,8,'/storage/vamola/169_2018-10-30.txt','2018-10-30',169,NULL,NULL),(30,5,163,3,0,0,12,7,8,'/storage/vamola/170_2018-10-30.txt','2018-10-30',170,NULL,NULL),(39,0,492,0,0,0,11,7,7,'/storage/vamola/112_2018-10-30.txt','2018-10-30',112,NULL,NULL),(40,6,477,2,0,0,11,7,7,'/storage/vamola/113_2018-10-30.txt','2018-10-30',113,NULL,NULL),(41,16,502,3,1,1,13,7,7,'/storage/vamola/114_2018-10-30.txt','2018-10-30',114,NULL,NULL),(42,0,703,0,0,0,13,7,7,'/storage/vamola/115_2018-10-30.txt','2018-10-30',115,NULL,NULL),(43,0,42,0,0,0,6,2,2,'/storage/vamola/116_2018-10-30.txt','2018-10-30',116,NULL,NULL),(44,10,434,3,1,0,12,7,7,'/storage/vamola/117_2018-10-30.txt','2018-10-30',117,NULL,NULL),(45,0,36,0,0,0,6,2,2,'/storage/vamola/118_2018-10-30.txt','2018-10-30',118,NULL,NULL),(46,12,442,3,0,0,12,7,7,'/storage/vamola/119_2018-10-30.txt','2018-10-30',119,NULL,NULL),(47,1,468,1,0,0,11,7,7,'/storage/vamola/120_2018-10-30.txt','2018-10-30',120,NULL,NULL);
/*!40000 ALTER TABLE `vamolas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waves`
--

DROP TABLE IF EXISTS `waves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `waves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_advertencias` int(11) NOT NULL DEFAULT '0',
  `num_caracteristicas` int(11) NOT NULL DEFAULT '0',
  `num_elem_ARIA` int(11) NOT NULL DEFAULT '0',
  `num_problemas_contraste` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waves_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `waves_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waves`
--

LOCK TABLES `waves` WRITE;
/*!40000 ALTER TABLE `waves` DISABLE KEYS */;
INSERT INTO `waves` VALUES (1,0,30,13,4,0,'/storage/wave/22_2018-10-30.txt','2018-10-30',22,NULL,NULL),(2,0,28,13,4,0,'/storage/wave/23_2018-10-30.txt','2018-10-30',23,NULL,NULL),(3,0,19,15,4,0,'/storage/wave/24_2018-10-30.txt','2018-10-30',24,NULL,NULL),(4,0,16,13,4,0,'/storage/wave/25_2018-10-30.txt','2018-10-30',25,NULL,NULL),(5,0,16,13,4,0,'/storage/wave/26_2018-10-30.txt','2018-10-30',26,NULL,NULL),(6,0,20,14,4,0,'/storage/wave/27_2018-10-30.txt','2018-10-30',27,NULL,NULL),(7,0,19,19,4,0,'/storage/wave/29_2018-10-30.txt','2018-10-30',29,NULL,NULL),(8,0,19,27,4,0,'/storage/wave/30_2018-10-30.txt','2018-10-30',30,NULL,NULL),(9,0,19,28,17,0,'/storage/wave/21_2018-10-30.txt','2018-10-30',21,NULL,NULL),(10,3,57,58,84,21,'/storage/wave/91_2018-10-30.txt','2018-10-30',91,NULL,NULL),(11,0,16,13,4,0,'/storage/wave/28_2018-10-30.txt','2018-10-30',28,NULL,NULL),(12,7,73,66,94,36,'/storage/wave/92_2018-10-30.txt','2018-10-30',92,NULL,NULL),(13,7,73,66,94,36,'/storage/wave/93_2018-10-30.txt','2018-10-30',93,NULL,NULL),(14,7,73,66,94,36,'/storage/wave/94_2018-10-30.txt','2018-10-30',94,NULL,NULL),(15,28,50,59,178,29,'/storage/wave/95_2018-10-30.txt','2018-10-30',95,NULL,NULL),(16,49,81,52,84,28,'/storage/wave/96_2018-10-30.txt','2018-10-30',96,NULL,NULL),(17,7,67,69,78,16,'/storage/wave/97_2018-10-30.txt','2018-10-30',97,NULL,NULL),(18,10,194,103,121,19,'/storage/wave/98_2018-10-30.txt','2018-10-30',98,NULL,NULL),(19,9,95,71,90,16,'/storage/wave/99_2018-10-30.txt','2018-10-30',99,NULL,NULL),(20,7,70,73,85,16,'/storage/wave/100_2018-10-30.txt','2018-10-30',100,NULL,NULL),(21,9,71,36,14,12,'/storage/wave/161_2018-10-30.txt','2018-10-30',161,NULL,NULL),(22,9,71,36,14,12,'/storage/wave/162_2018-10-30.txt','2018-10-30',162,NULL,NULL),(23,3,73,14,0,10,'/storage/wave/163_2018-10-30.txt','2018-10-30',163,NULL,NULL),(24,3,62,5,5,10,'/storage/wave/164_2018-10-30.txt','2018-10-30',164,NULL,NULL),(25,3,61,6,5,10,'/storage/wave/165_2018-10-30.txt','2018-10-30',165,NULL,NULL),(26,3,66,8,5,11,'/storage/wave/166_2018-10-30.txt','2018-10-30',166,NULL,NULL),(27,3,61,6,5,10,'/storage/wave/167_2018-10-30.txt','2018-10-30',167,NULL,NULL),(28,3,62,6,5,10,'/storage/wave/168_2018-10-30.txt','2018-10-30',168,NULL,NULL),(29,3,61,5,5,10,'/storage/wave/169_2018-10-30.txt','2018-10-30',169,NULL,NULL),(30,3,61,5,5,10,'/storage/wave/170_2018-10-30.txt','2018-10-30',170,NULL,NULL);
/*!40000 ALTER TABLE `waves` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-30 17:46:01
