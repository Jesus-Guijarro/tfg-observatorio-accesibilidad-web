-- MySQL dump 10.13  Distrib 8.0.13, for Linux (x86_64)
--
-- Host: localhost    Database: OSAW
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessmonitors`
--

DROP TABLE IF EXISTS `accessmonitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `accessmonitors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aaa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_a` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aa` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accessmonitors_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `accessmonitors_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessmonitors`
--

LOCK TABLES `accessmonitors` WRITE;
/*!40000 ALTER TABLE `accessmonitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessmonitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acheckers`
--

DROP TABLE IF EXISTS `acheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `acheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `acheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `acheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acheckers`
--

LOCK TABLES `acheckers` WRITE;
/*!40000 ALTER TABLE `acheckers` DISABLE KEYS */;
/*!40000 ALTER TABLE `acheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Ministerios y agencias estatales',NULL,NULL),(2,'Entidades autonómicas y locales',NULL,NULL),(3,'Entidades públicas empresariales',NULL,NULL),(4,'Centros universitarios públicos',NULL,NULL),(5,'Empresas privadas',NULL,NULL);
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eiiicheckers`
--

DROP TABLE IF EXISTS `eiiicheckers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `eiiicheckers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `puntuacion` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_aciertos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_aa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `eiiicheckers_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `eiiicheckers_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eiiicheckers`
--

LOCK TABLES `eiiicheckers` WRITE;
/*!40000 ALTER TABLE `eiiicheckers` DISABLE KEYS */;
/*!40000 ALTER TABLE `eiiicheckers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1028 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1015,'2018_10_01_211102_create_rols_table',1),(1016,'2018_10_02_000000_create_users_table',1),(1017,'2018_10_02_100000_create_password_resets_table',1),(1018,'2018_10_04_223958_create_categorias_table',1),(1019,'2018_10_05_223735_create_sitios_table',1),(1020,'2018_10_06_223729_create_paginas_table',1),(1021,'2018_10_07_223910_create_user_pagina_table',1),(1022,'2018_10_20_211356_create_accessmonitors_table',1),(1023,'2018_10_20_211408_create_acheckers_table',1),(1024,'2018_10_20_211409_create_eiiicheckers_table',1),(1025,'2018_10_20_211503_create_observatorios_table',1),(1026,'2018_10_20_211509_create_vamolas_table',1),(1027,'2018_10_20_211516_create_waves_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `observatorios`
--

DROP TABLE IF EXISTS `observatorios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `observatorios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `porcentaje_comprensible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_operable` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_perceptible` double(8,2) NOT NULL DEFAULT '0.00',
  `porcentaje_robusto` double(8,2) NOT NULL DEFAULT '0.00',
  `num_problemas_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_operable` int(11) NOT NULL DEFAULT '0',
  `num_problemas_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_problemas_robusto` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_comprensible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_operable` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_perceptible` int(11) NOT NULL DEFAULT '0',
  `num_advertencias_robusto` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `observatorios_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `observatorios_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `observatorios`
--

LOCK TABLES `observatorios` WRITE;
/*!40000 ALTER TABLE `observatorios` DISABLE KEYS */;
/*!40000 ALTER TABLE `observatorios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paginas`
--

DROP TABLE IF EXISTS `paginas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `paginas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `URL` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `archivo_HTML` text COLLATE utf8mb4_unicode_ci,
  `hash` char(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `sitio_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paginas_sitio_id_foreign` (`sitio_id`),
  CONSTRAINT `paginas_sitio_id_foreign` FOREIGN KEY (`sitio_id`) REFERENCES `sitios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paginas`
--

LOCK TABLES `paginas` WRITE;
/*!40000 ALTER TABLE `paginas` DISABLE KEYS */;
INSERT INTO `paginas` VALUES (1,'http://www.mjusticia.gob.es',NULL,'default',1,NULL,NULL),(2,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/atencion-ciudadano',NULL,'default',1,NULL,NULL),(3,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/ministerio/funciones-estructura',NULL,'default',1,NULL,NULL),(4,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/ministerio/organismos-entidades',NULL,'default',1,NULL,NULL),(5,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/administracion-justicia/organizacion-justicia',NULL,'default',1,NULL,NULL),(6,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/servicios-ciudadano/tramites-gestiones-personales',NULL,'default',1,NULL,NULL),(7,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/servicios-ciudadano/empleo-publico',NULL,'default',1,NULL,NULL),(8,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/areas-tematicas/registros',NULL,'default',1,NULL,NULL),(9,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/actividad-legislativa/normativa',NULL,'default',1,NULL,NULL),(10,'http://www.mjusticia.gob.es/cs/Satellite/Portal/es/justicia-espana/organizacion',NULL,'default',1,NULL,NULL),(11,'https://www.agenciatributaria.es/',NULL,'default',2,NULL,NULL),(12,'https://www.agenciatributaria.es/AEAT.internet/Renta.shtml',NULL,'default',2,NULL,NULL),(13,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Minimos__reducciones_y_deducciones_en_el_IRPF/Minimos__reducciones_y_deducciones_en_el_IRPF.shtml',NULL,'default',2,NULL,NULL),(14,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Vivienda/Vivienda.shtml',NULL,'default',2,NULL,NULL),(15,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Ciudadanos.shtml',NULL,'default',2,NULL,NULL),(16,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Discapacitados/Discapacitados.shtml',NULL,'default',2,NULL,NULL),(17,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Tramites_electronicos/Tramites_electronicos.shtml',NULL,'default',2,NULL,NULL),(18,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Certificados_tributarios/Certificados_tributarios.shtml',NULL,'default',2,NULL,NULL),(19,'https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Ciudadanos/Limitacion_de_pagos_en_efectivo/Limitacion_de_pagos_en_efectivo.shtml',NULL,'default',2,NULL,NULL),(20,'https://www.agenciatributaria.es/AEAT.internet/Inicio/La_Agencia_Tributaria/Campanas/Censos__NIF_y_domicilio_fiscal/Ciudadanos/Ciudadanos.shtml',NULL,'default',2,NULL,NULL),(21,'http://www.gva.es',NULL,'default',3,NULL,NULL),(22,'http://www.gva.es/es/inicio/administraciones',NULL,'default',3,NULL,NULL),(23,'http://www.gva.es/es/inicio/ciudadanos',NULL,'default',3,NULL,NULL),(24,'http://www.gva.es/es/inicio/ciudadanos/ciu_busco_trabajo',NULL,'default',3,NULL,NULL),(25,'http://www.gva.es/es/inicio/ciudadanos/ciu_quiero_acceder_a_una_vivienda',NULL,'default',3,NULL,NULL),(26,'http://www.gva.es/es/inicio/ciudadanos/ciu_quiero_estudiar_y_formarme',NULL,'default',3,NULL,NULL),(27,'http://www.gva.es/es/inicio/ciudadanos/ciu_necesito_ir_al_medico',NULL,'default',3,NULL,NULL),(28,'http://www.gva.es/es/inicio/ciudadanos/ciu_necesito_informacion_tributaria',NULL,'default',3,NULL,NULL),(29,'http://www.gva.es/es/inicio/administraciones/adm_tramites_y_servicios',NULL,'default',3,NULL,NULL),(30,'http://www.gva.es/es/inicio/administraciones/adm_ayudas_y_subvenciones',NULL,'default',3,NULL,NULL),(31,'http://www.alicante.es',NULL,'default',4,NULL,NULL),(32,'http://www.alicante.es/es/contenidos/servicios-emergencia',NULL,'default',4,NULL,NULL),(33,'http://www.alicante.es/es/area-tematica/servicio-de-atencion-integral-a-la-ciudadania---saic',NULL,'default',4,NULL,NULL),(34,'http://www.alicante.es/es/contenidos/ciudad-alicante',NULL,'default',4,NULL,NULL),(35,'http://www.alicante.es/es/galerias_imagen',NULL,'default',4,NULL,NULL),(36,'http://www.alicante.es/es/area-tematica/turismo',NULL,'default',4,NULL,NULL),(37,'http://www.alicante.es/es/noticias/actualizacion-del-espacio-participacion-ciudadana',NULL,'default',4,NULL,NULL),(38,'http://www.alicante.es/es/contenidos/transporte-alicante-metropolitano-tam',NULL,'default',4,NULL,NULL),(39,'http://www.alicante.es/es/area-tematica/seguridad-ciudadana',NULL,'default',4,NULL,NULL),(40,'http://www.alicante.es/es/area-tematica/comercio-consumo-sanidad',NULL,'default',4,NULL,NULL),(41,'http://www.renfe.com',NULL,'default',5,NULL,NULL),(42,'http://www.renfe.com/empresa/atencion_cliente/index.html',NULL,'default',5,NULL,NULL),(43,'http://www.renfe.com/viajeros/atendo/index.html',NULL,'default',5,NULL,NULL),(44,'http://www.renfe.com/empresa/comunicacion/incidencias.html',NULL,'default',5,NULL,NULL),(45,'http://www.renfe.com/viajeros/atendo/estaciones.html',NULL,'default',5,NULL,NULL),(46,'http://www.renfe.com/viajeros/info/index.html',NULL,'default',5,NULL,NULL),(47,'http://www.renfe.com/viajeros/tarifas/index.html',NULL,'default',5,NULL,NULL),(48,'http://www.renfe.com/viajeros/atendo/informacion_cliente.html',NULL,'default',5,NULL,NULL),(49,'http://www.renfe.com/viajeros/movilidad/index.html',NULL,'default',5,NULL,NULL),(50,'http://www.renfe.com/viajeros/cercanias/index.html',NULL,'default',5,NULL,NULL),(51,'https://www.cdti.es',NULL,'default',6,NULL,NULL),(52,'https://www.cdti.es/index.asp?MP=6&MS=5&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(53,'https://www.cdti.es/index.asp?MP=100&MS=802&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(54,'https://www.cdti.es/index.asp?MP=8&MS=128&MN=2&r=1536*864',NULL,'default',6,NULL,NULL),(55,'https://www.cdti.es/index.asp?MP=101&MS=821&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(56,'https://www.cdti.es/index.asp?MP=8&MS=69&MN=2&r=1536*864',NULL,'default',6,NULL,NULL),(57,'https://www.cdti.es/index.asp?MP=8&MS=129&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(58,'https://www.cdti.es/index.asp?MP=9&MS=31&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(59,'https://www.cdti.es/index.asp?MP=99&MS=0&MN=1&r=1536*864',NULL,'default',6,NULL,NULL),(60,'https://www.cdti.es/index.asp?MP=20&MS=0&MN=1',NULL,'default',6,NULL,NULL),(61,'https://www.upv.es',NULL,'default',7,NULL,NULL),(62,'https://www.upv.es/perfiles/futuro-alumno/index-es.html',NULL,'default',7,NULL,NULL),(63,'https://www.upv.es/admision/empezar-en-la-universidad/index-es.html',NULL,'default',7,NULL,NULL),(64,'https://www.upv.es/admision/traslados-e-intercambios/index-es.html',NULL,'default',7,NULL,NULL),(65,'https://www.upv.es/estudios/grado/index-es.html',NULL,'default',7,NULL,NULL),(66,'https://www.upv.es/estudios/aula-abierta/index-es.html',NULL,'default',7,NULL,NULL),(67,'https://www.upv.es/investigacion/estructuras/index-es.html',NULL,'default',7,NULL,NULL),(68,'https://www.upv.es/investigacion/iniciativas-idi/index-es.html',NULL,'default',7,NULL,NULL),(69,'https://www.upv.es/organizacion/escuelas-facultades/index-es.html',NULL,'default',7,NULL,NULL),(70,'https://www.upv.es/organizacion/departamentos/index-es.html',NULL,'default',7,NULL,NULL),(71,'https://web.ua.es',NULL,'default',8,NULL,NULL),(72,'https://web.ua.es/es/estudia-en-la-ua.html',NULL,'default',8,NULL,NULL),(73,'https://web.ua.es/es/orientacion-y-empleo.html',NULL,'default',8,NULL,NULL),(74,'https://web.ua.es/es/grados-oficiales.html',NULL,'default',8,NULL,NULL),(75,'https://web.ua.es/es/masteres-oficiales.html',NULL,'default',8,NULL,NULL),(76,'https://web.ua.es/es/investiga-en-la-ua.html',NULL,'default',8,NULL,NULL),(77,'https://web.ua.es/es/movilidad.html',NULL,'default',8,NULL,NULL),(78,'https://web.ua.es/es/centros-departamentos-e-institutos.html',NULL,'default',8,NULL,NULL),(79,'https://web.ua.es/es/recursos-universitarios.html',NULL,'default',8,NULL,NULL),(80,'https://web.ua.es/es/centro-de-apoyo-al-estudiante.html',NULL,'default',8,NULL,NULL),(81,'https://www.endesaclientes.com',NULL,'default',9,NULL,NULL),(82,'https://www.endesaclientes.com/hogares/atencion-cliente.html',NULL,'default',9,NULL,NULL),(83,'https://www.endesaclientes.com/facturas-lecturas',NULL,'default',9,NULL,NULL),(84,'https://www.endesaclientes.com/facturas-lecturas/ver-factura',NULL,'default',9,NULL,NULL),(85,'https://www.endesaclientes.com/facturas-lecturas/pagar-facturas',NULL,'default',9,NULL,NULL),(86,'https://www.endesaclientes.com/facturas-lecturas/dar-lectura',NULL,'default',9,NULL,NULL),(87,'https://www.endesaclientes.com/explicacion-factura.html',NULL,'default',9,NULL,NULL),(88,'https://www.endesaclientes.com/factura-electronica.html',NULL,'default',9,NULL,NULL),(89,'https://www.endesaclientes.com/hogares/mantenimiento.html',NULL,'default',9,NULL,NULL),(90,'https://www.endesaclientes.com/gestiones-contratos',NULL,'default',9,NULL,NULL),(91,'https://www.iberdrola.es',NULL,'default',10,NULL,NULL),(92,'https://www.iberdrola.es/atencion-cliente',NULL,'default',10,NULL,NULL),(93,'https://www.iberdrola.es/atencion-cliente#form-consultas',NULL,'default',10,NULL,NULL),(94,'https://www.iberdrola.es/atencion-cliente#panel-extranjero',NULL,'default',10,NULL,NULL),(95,'https://www.iberdrola.es/ahorrar-energia/calcular-potencia-electrica-optima',NULL,'default',10,NULL,NULL),(96,'https://www.iberdrola.es/informacion/facturas',NULL,'default',10,NULL,NULL),(97,'https://www.iberdrola.es/informacion/alta-nuevo-suministro-electrico',NULL,'default',10,NULL,NULL),(98,'https://www.iberdrola.es/informacion/instalacion-electricidad',NULL,'default',10,NULL,NULL),(99,'https://www.iberdrola.es/informacion/instalacion-gas',NULL,'default',10,NULL,NULL),(100,'https://www.iberdrola.es/informacion/alta-nuevo-suministro-gas',NULL,'default',10,NULL,NULL),(101,'https://www.bancosantander.es',NULL,'default',23,NULL,NULL),(102,'https://www.bancosantander.es/es/particulares/prestamos',NULL,'default',23,NULL,NULL),(103,'https://www.bancosantander.es/es/particulares/cuentas-y-tarjetas',NULL,'default',23,NULL,NULL),(104,'https://www.bancosantander.es/es/particulares/ahorro-e-inversion',NULL,'default',23,NULL,NULL),(105,'https://www.bancosantander.es/es/particulares/hipotecas',NULL,'default',23,NULL,NULL),(106,'https://www.bancosantander.es/es/particulares/prestamos',NULL,'default',23,NULL,NULL),(107,'https://www.bancosantander.es/es/particulares/banca-online',NULL,'default',23,NULL,NULL),(108,'https://www.bancosantander.es/es/particulares/hazte-cliente',NULL,'default',23,NULL,NULL),(109,'https://www.bancosantander.es/es/particulares/banca-online/clave-online',NULL,'default',23,NULL,NULL),(110,'https://www.bancosantander.es/es/particulares/banca-online/internet',NULL,'default',23,NULL,NULL),(111,'https://www.iberia.com/',NULL,'default',24,NULL,NULL),(112,'https://www.iberia.com/es/buscador-vuelos/',NULL,'default',24,NULL,NULL),(113,'https://www.iberia.com/es/puente-aereo/',NULL,'default',24,NULL,NULL),(114,'https://www.iberia.com/es/vuelo+hotel/',NULL,'default',24,NULL,NULL),(115,'https://www.iberia.com/es/atencion-al-cliente/#',NULL,'default',24,NULL,NULL),(116,'https://www.iberia.com/es/autocheckin-online/?language=es&market=es#/ibcose',NULL,'default',24,NULL,NULL),(117,'https://www.iberia.com/es/informacion-checkin/',NULL,'default',24,NULL,NULL),(118,'https://www.iberia.com/es/gestion-de-reservas/?language=es&market=es&channel=COM#!/chktrp',NULL,'default',24,NULL,NULL),(119,'https://www.iberia.com/es/facturas/',NULL,'default',24,NULL,NULL),(120,'https://www.iberia.com/es/horarios/',NULL,'default',24,NULL,NULL),(121,'http://www.mscbs.gob.es/#',NULL,'default',11,NULL,NULL),(122,'http://www.mscbs.gob.es/#aldia-sanidad',NULL,'default',11,NULL,NULL),(123,'http://www.mscbs.gob.es/#aldia-servicios',NULL,'default',11,NULL,NULL),(124,'http://www.mscbs.gob.es/#fotos',NULL,'default',11,NULL,NULL),(125,'http://www.mscbs.gob.es/#videos',NULL,'default',11,NULL,NULL),(126,'http://www.mscbs.gob.es/accesibilidad/home.htm',NULL,'default',11,NULL,NULL),(127,'http://www.mscbs.gob.es/avisoLegal/home.htm',NULL,'default',11,NULL,NULL),(128,'http://www.mscbs.gob.es/avisoLegal/home.htm#politicaCookie',NULL,'default',11,NULL,NULL),(129,'http://www.mscbs.gob.es/biblioPublic/biblioDocum/home.htm',NULL,'default',11,NULL,NULL),(130,'http://www.mscbs.gob.es/biblioPublic/portada/home.htm',NULL,'default',11,NULL,NULL),(131,'http://www.ciencia.gob.es/',NULL,'default',12,NULL,NULL),(132,'http://www.ciencia.gob.es/#',NULL,'default',12,NULL,NULL),(133,'http://www.ciencia.gob.es/#abre',NULL,'default',12,NULL,NULL),(134,'http://www.ciencia.gob.es/#tab1',NULL,'default',12,NULL,NULL),(135,'http://www.ciencia.gob.es/portal/site/MICINN/contacto',NULL,'default',12,NULL,NULL),(136,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.00d7c011ca2a3753222b7d1001432ea0/?vgnextoid=33881f4368aef110VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(137,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.00d7c011ca2a3753222b7d1001432ea0/?vgnextoid=f4c81f4368aef110VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(138,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=0b6ac76c760d4610VgnVCM1000001d04140aRCRD',NULL,'default',12,NULL,NULL),(139,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=25c55ef3677c4610VgnVCM1000001d04140aRCRD',NULL,'default',12,NULL,NULL),(140,'http://www.ciencia.gob.es/portal/site/MICINN/menuitem.26172fcf4eb029fa6ec7da6901432ea0/?vgnextoid=f0c992106a8a3210VgnVCM1000001034e20aRCRD&vgnextchannel=f0c992106a8a3210VgnVCM1000001034e20aRCRD',NULL,'default',12,NULL,NULL),(141,'http://www.mecd.gob.es/accesibilidad-mecd/',NULL,'default',13,NULL,NULL),(142,'http://www.mecd.gob.es/aviso-legal-mecd/',NULL,'default',13,NULL,NULL),(143,'http://www.mecd.gob.es/cultura-mecd/',NULL,'default',13,NULL,NULL),(144,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/archivos.html',NULL,'default',13,NULL,NULL),(145,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/artesescenicas.html',NULL,'default',13,NULL,NULL),(146,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/bibliotecas.html',NULL,'default',13,NULL,NULL),(147,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/cine.html',NULL,'default',13,NULL,NULL),(148,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/cooperacion.html',NULL,'default',13,NULL,NULL),(149,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/industriasculturales.html',NULL,'default',13,NULL,NULL),(150,'http://www.mecd.gob.es/cultura-mecd/areas-cultura/libro.html',NULL,'default',13,NULL,NULL),(151,'https://www.aemps.gob.es/accesibilidad/home.htm',NULL,'default',15,NULL,NULL),(152,'https://www.aemps.gob.es/avisoLegal/home.htm',NULL,'default',15,NULL,NULL),(153,'https://www.aemps.gob.es/avisoLegal/home.htm#cookies',NULL,'default',15,NULL,NULL),(154,'https://www.aemps.gob.es/ca/home.htm',NULL,'default',15,NULL,NULL),(155,'https://www.aemps.gob.es/cosmeticosHigiene/portada/home.htm',NULL,'default',15,NULL,NULL),(156,'https://www.aemps.gob.es/en/home.htm',NULL,'default',15,NULL,NULL),(157,'https://www.aemps.gob.es/eu/home.htm',NULL,'default',15,NULL,NULL),(158,'https://www.aemps.gob.es/gl/home.htm',NULL,'default',15,NULL,NULL),(159,'https://www.aemps.gob.es/guiaNav/home.htm',NULL,'default',15,NULL,NULL),(160,'https://www.aemps.gob.es/home.htm',NULL,'default',15,NULL,NULL),(161,'http://www.raspeig.es/',NULL,'default',17,NULL,NULL),(162,'http://www.raspeig.es/#',NULL,'default',17,NULL,NULL),(163,'http://www.raspeig.es/actualidad/',NULL,'default',17,NULL,NULL),(164,'http://www.raspeig.es/actualidad/arranca-en-las-calles-vicente-savall-y-alfonso-xiii-el-nuevo-plan-de-poda-de-ciudad/',NULL,'default',17,NULL,NULL),(165,'http://www.raspeig.es/actualidad/bicisanvi-incorpora-30-unidades-con-marchas-y-luces/',NULL,'default',17,NULL,NULL),(166,'http://www.raspeig.es/actualidad/brillante-cierre-del-mig-any-con-el-concierto-de-l-associacio-musical-l-avanc-y-la-entrega-de-los-premios-de-bandas-y-collas-2018/',NULL,'default',17,NULL,NULL),(167,'http://www.raspeig.es/actualidad/comercio-entre-calles-el-viernes-2-de-noviembre/',NULL,'default',17,NULL,NULL),(168,'http://www.raspeig.es/actualidad/comercio-entre-calles-queda-aplazado-ante-la-prevision-de-chubascos/',NULL,'default',17,NULL,NULL),(169,'http://www.raspeig.es/actualidad/el-ayuntamiento-lanza-una-nueva-oferta-publica-de-viviendas-con-finalidad-social/',NULL,'default',17,NULL,NULL),(170,'http://www.raspeig.es/actualidad/la-nueva-ordenanza-de-animales-de-compania-ampara-la-regulacion-de-las-colonias-felinas/',NULL,'default',17,NULL,NULL),(171,'http://www.valencia.es/',NULL,'default',18,NULL,NULL),(172,'http://www.valencia.es/Contratacion/pdc_Fallera.nsf/fCategoriaVistaExpedientes?readForm&Vista=vLicitaciones_encurso&Categoria=Servicio%20de%20Contrataci%F3n&titulo=Licitaciones%20en%20curso&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(173,'http://www.valencia.es/Contratacion/pdc_universidad.nsf/fCategoriaVistaExpedientes?readForm&Vista=vLicitaciones_encursov&Categoria=Servici%20de%20Contractaci%F3&titulo=Licitacions%20en%20curs&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(174,'http://www.valencia.es/agenciabici/va',NULL,'default',18,NULL,NULL),(175,'http://www.valencia.es/ayuntamiento/AInstitucional.nsf/fCategoriaVista2?readForm&nivel=8&Vista=vActivAIWv&Categoria=Actividades&lang=2&expand=2&nivelExpandido=1.1.1&bdorigen=ayuntamiento/ayuntamiento.nsf',NULL,'default',18,NULL,NULL),(176,'http://www.valencia.es/ayuntamiento/ConsejosDisAct.nsf/fCategoriaVista2?readForm&Vista=vComisionesTodasVal&Categoria=Consejos&lang=2&nivel=3%5f5&nivelExpandido=1&bdorigen=ayuntamiento/ayuntamiento.nsf&idapoyo=9A0B3E8F6AB1CDBAC12582410042C735',NULL,'default',18,NULL,NULL),(177,'http://www.valencia.es/ayuntamiento/Mercados.nsf/vDocumentosTituloAux/Inicio?opendocument&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(178,'http://www.valencia.es/ayuntamiento/OMIDC.nsf/vDocumentosTituloAux/Inicio?opendocument&lang=2&nivel=1',NULL,'default',18,NULL,NULL),(179,'http://www.valencia.es/ayuntamiento/WebCiudano.nsf/Registro?ReadForm&lang=2&id=0F3E93B421616BDEC1257F46002D260A&estado=0&nivel=2_2&bdorigen=ayuntamiento/ayuntamiento.nsf',NULL,'default',18,NULL,NULL),(180,'http://www.valencia.es/ayuntamiento/agenda_accesible.nsf/Agenda/001E7DF55397BF5DC125830100429CBA?OpenDocument&lang=2&nivel=4&bdOrigen=ayuntamiento/laciudad.nsf',NULL,'default',18,NULL,NULL),(181,'http://www.idae.es/',NULL,'default',19,NULL,NULL),(182,'http://www.idae.es/#',NULL,'default',19,NULL,NULL),(183,'http://www.idae.es/#main-content',NULL,'default',19,NULL,NULL),(184,'http://www.idae.es/accesibilidad-wai-aa',NULL,'default',19,NULL,NULL),(185,'http://www.idae.es/ahorra-energia',NULL,'default',19,NULL,NULL),(186,'http://www.idae.es/ahorra-energia/aula-digital-aprende-ahorrar-energia',NULL,'default',19,NULL,NULL),(187,'http://www.idae.es/ahorra-energia/campanas-y-acciones-de-acompanamiento',NULL,'default',19,NULL,NULL),(188,'http://www.idae.es/ahorra-energia/nuevo-reglamento-para-el-etiquetado-energetico',NULL,'default',19,NULL,NULL),(189,'http://www.idae.es/ahorra-energia/renovables-de-uso-domestico/programa-biomcasa-ii',NULL,'default',19,NULL,NULL),(190,'http://www.idae.es/ahorra-energia/renovables-de-uso-domestico/programa-geotcasa',NULL,'default',19,NULL,NULL),(191,'http://www.umh.es/#',NULL,'default',21,NULL,NULL),(192,'http://www.umh.es/?lang=EN',NULL,'default',21,NULL,NULL),(193,'http://www.umh.es/?lang=ES',NULL,'default',21,NULL,NULL),(194,'http://www.umh.es/?lang=VAL',NULL,'default',21,NULL,NULL),(195,'http://www.umh.es/acc/',NULL,'default',21,NULL,NULL),(196,'http://www.umh.es/contenido/AdmisionAyudas/:admision_ayudas/datos_es.html',NULL,'default',21,NULL,NULL),(197,'http://www.umh.es/contenido/Alumni/:none/datos_es.html',NULL,'default',21,NULL,NULL),(198,'http://www.umh.es/contenido/Alumni/:utilidades_alumni/datos_es.html',NULL,'default',21,NULL,NULL),(199,'http://www.umh.es/contenido/Estudiantes/:CEGECA/datos_es.html',NULL,'default',21,NULL,NULL),(200,'http://www.umh.es/contenido/Estudiantes/:Curso_Adaptacion_Grado/datos_es.html',NULL,'default',21,NULL,NULL),(201,'https://www.uv.es/#',NULL,'default',22,NULL,NULL),(202,'https://www.uv.es/#home',NULL,'default',22,NULL,NULL),(203,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/1-escull-master.html',NULL,'default',22,NULL,NULL),(204,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/2-lliura-documentacio.html',NULL,'default',22,NULL,NULL),(205,'https://www.uv.es/master-ultimes-places/ca/admissio-master/admissio-ultimes-places/3-espera-notificacio-admissio-max-24h-.html',NULL,'default',22,NULL,NULL),(206,'https://www.uv.es/master-ultimes-places/ca/masters-oficials.html',NULL,'default',22,NULL,NULL),(207,'https://www.uv.es/master-ultimes-places/ca/normativa-basica/normativa-basica.html',NULL,'default',22,NULL,NULL),(208,'https://www.uv.es/recull',NULL,'default',22,NULL,NULL),(209,'https://www.uv.es/uvnoticies',NULL,'default',22,NULL,NULL),(210,'https://www.uv.es/uvweb/college/en/university-valencia-1285845048380.html',NULL,'default',22,NULL,NULL),(211,'http://www.mitramiss.gob.es/#',NULL,'default',14,NULL,NULL),(212,'http://www.mitramiss.gob.es/ca/index.htm',NULL,'default',14,NULL,NULL),(213,'http://www.mitramiss.gob.es/cartaespana/index.htm',NULL,'default',14,NULL,NULL),(214,'http://www.mitramiss.gob.es/en/index.htm',NULL,'default',14,NULL,NULL),(215,'http://www.mitramiss.gob.es/es/Guia/texto/index.htm',NULL,'default',14,NULL,NULL),(216,'http://www.mitramiss.gob.es/es/contacto_ministerio/index.htm',NULL,'default',14,NULL,NULL),(217,'http://www.mitramiss.gob.es/es/el_ministerio/index.htm',NULL,'default',14,NULL,NULL),(218,'http://www.mitramiss.gob.es/es/estadisticas/index.htm',NULL,'default',14,NULL,NULL),(219,'http://www.mitramiss.gob.es/es/extras/accesibilidad.htm',NULL,'default',14,NULL,NULL),(220,'http://www.mitramiss.gob.es/es/extras/avisolegal.htm',NULL,'default',14,NULL,NULL),(221,'http://www.aemet.es/ca/portada',NULL,'default',16,NULL,NULL),(222,'http://www.aemet.es/en/portada',NULL,'default',16,NULL,NULL),(223,'http://www.aemet.es/es/accesibilidad',NULL,'default',16,NULL,NULL),(224,'http://www.aemet.es/es/app/eltiempodeAEMET',NULL,'default',16,NULL,NULL),(225,'http://www.aemet.es/es/ayuda',NULL,'default',16,NULL,NULL),(226,'http://www.aemet.es/es/conocenos',NULL,'default',16,NULL,NULL),(227,'http://www.aemet.es/es/conocenos/a_que_nos_dedicamos',NULL,'default',16,NULL,NULL),(228,'http://www.aemet.es/es/conocenos/colaboracion_institucional/convenios',NULL,'default',16,NULL,NULL),(229,'http://www.aemet.es/es/conocenos/congresos_y_conferencias',NULL,'default',16,NULL,NULL),(230,'http://www.aemet.es/es/conocenos/congresos_y_conferencias/congresos',NULL,'default',16,NULL,NULL),(231,'https://www.icex.es/icex/es/',NULL,'default',20,NULL,NULL),(232,'https://www.icex.es/icex/es/Navegacion-zona-contacto/libreria-icex/index.html',NULL,'default',20,NULL,NULL),(233,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/empresas/index.html',NULL,'default',20,NULL,NULL),(234,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/en-cifras/index.html',NULL,'default',20,NULL,NULL),(235,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/index.html',NULL,'default',20,NULL,NULL),(236,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/invertir/index.html',NULL,'default',20,NULL,NULL),(237,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/mercados/index.html',NULL,'default',20,NULL,NULL),(238,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/mundo/index.html',NULL,'default',20,NULL,NULL),(239,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/noticias/index.html',NULL,'default',20,NULL,NULL),(240,'https://www.icex.es/icex/es/Navegacion-zona-contacto/revista-el-exportador/observatorio2/index.html',NULL,'default',20,NULL,NULL);
/*!40000 ALTER TABLE `paginas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rols`
--

DROP TABLE IF EXISTS `rols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `rols` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rols`
--

LOCK TABLES `rols` WRITE;
/*!40000 ALTER TABLE `rols` DISABLE KEYS */;
INSERT INTO `rols` VALUES (1,'Colaborador',NULL,NULL),(2,'Experto',NULL,NULL),(3,'Administrador',NULL,NULL);
/*!40000 ALTER TABLE `rols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitios`
--

DROP TABLE IF EXISTS `sitios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sitios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dominio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodicidad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dia` int(11) NOT NULL,
  `automatizado` tinyint(1) NOT NULL,
  `num_paginas` int(11) NOT NULL,
  `herramientas` json NOT NULL,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitios_nombre_unique` (`nombre`),
  KEY `sitios_categoria_id_foreign` (`categoria_id`),
  CONSTRAINT `sitios_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitios`
--

LOCK TABLES `sitios` WRITE;
/*!40000 ALTER TABLE `sitios` DISABLE KEYS */;
INSERT INTO `sitios` VALUES (1,'Ministerio de Justicia','www.mjusticia.gob.es','Semanal','13:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL),(2,'Agencia Estatal de Administración Tributaria','www.agenciatributaria.es','Semanal','13:00',1,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',1,NULL,NULL),(3,'Generalitat Valenciana','www.gva.es','Semanal','13:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',2,NULL,NULL),(4,'Ayuntamiento de Alicante','www.alicante.es','Semanal','13:00',3,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',2,NULL,NULL),(5,'Red Nacional de los Ferrocarriles Españoles (RENFE)','www.renfe.com','Semanal','13:00',4,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(6,'Centro para el Desarrollo Tecnológico Industrial (CDTI)','www.cdti.es','Semanal','13:00',5,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(7,'Universitat Politècnica de València (UPV)','www.upv.es','Semanal','13:00',6,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',4,NULL,NULL),(8,'Universidad de Alicante (UA)','web.ua.es','Semanal','14:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',4,NULL,NULL),(9,'Endesa','/www.endesaclientes.com','Semanal','14:00',1,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(10,'Iberdrola','www.iberdrola.es','Semanal','14:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": true, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(11,'Ministerio de Sanidad, Consumo y Bienestar Social','www.mscbs.gob.es','Semanal','14:00',3,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(12,'Ministerio de Ciencia, Innovación y Universidades','www.ciencia.gob.es','Semanal','14:00',4,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(13,'Ministerio de Educación, Cultura y Deporte','www.mecd.gob.es','Semanal','14:00',5,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(14,'Ministerio de Trabajo, Migraciones y Seguridad Social','www.mitramiss.gob.es','Semanal','14:00',6,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(15,'Agencia Española de Medicamentos y Productos Sanitarios','www.aemps.gob.es','Semanal','15:00',0,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(16,'Agencia Estatal de Meterología','www.aemet.es','Semanal','15:00',1,1,10,'{\"wave\": true, \"vamola\": false, \"achecker\": true, \"eiiichecker\": false, \"observatorio\": true, \"accessmonitor\": false}',1,NULL,NULL),(17,'Ayuntamiento de San Vicente del Raspeig','www.raspeig.es','Semanal','15:00',2,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": false, \"accessmonitor\": false}',2,NULL,NULL),(18,'Ayuntamiento de Valencia','www.valencia.es','Semanal','15:00',3,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": false, \"accessmonitor\": false}',2,NULL,NULL),(19,'Instituto para la Diversificación y Ahorro de la Energía (IDAE)','www.idae.es','Semanal','15:00',4,1,10,'{\"wave\": false, \"vamola\": false, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(20,'Instituto Español de Comercio Exterior (ICEX)','www.icex.es','Semanal','15:00',5,1,10,'{\"wave\": false, \"vamola\": false, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',3,NULL,NULL),(21,'Universidad Miguel Hernández (UMH)','www.umh.es','Semanal','15:00',6,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": false, \"observatorio\": false, \"accessmonitor\": true}',4,NULL,NULL),(22,'Universitat de València (UV)','www.uv.es','Semanal','16:00',0,1,10,'{\"wave\": true, \"vamola\": true, \"achecker\": false, \"eiiichecker\": false, \"observatorio\": false, \"accessmonitor\": true}',4,NULL,NULL),(23,'Banco Santander','www.bancosantander.es','Semanal','16:00',1,1,10,'{\"wave\": false, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL),(24,'Iberia','www.iberia.com','Semanal','16:00',2,1,10,'{\"wave\": false, \"vamola\": true, \"achecker\": false, \"eiiichecker\": true, \"observatorio\": true, \"accessmonitor\": true}',5,NULL,NULL);
/*!40000 ALTER TABLE `sitios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_pagina`
--

DROP TABLE IF EXISTS `user_pagina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user_pagina` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `informe` json NOT NULL,
  `fecha_test` date NOT NULL,
  `revisado` tinyint(1) NOT NULL,
  `porcentaje_perceptible` double(8,2) NOT NULL,
  `porcentaje_operable` double(8,2) NOT NULL,
  `porcentaje_comprensible` double(8,2) NOT NULL,
  `porcentaje_robusto` double(8,2) NOT NULL,
  `num_errores_a` int(11) NOT NULL,
  `num_errores_aa` int(11) NOT NULL,
  `num_errores_aaa` int(11) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_pagina_user_id_foreign` (`user_id`),
  KEY `user_pagina_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `user_pagina_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_pagina_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_pagina`
--

LOCK TABLES `user_pagina` WRITE;
/*!40000 ALTER TABLE `user_pagina` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_pagina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `biografia` text COLLATE utf8mb4_unicode_ci,
  `rol_id` int(10) unsigned DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_nombre_unique` (`nombre`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_rol_id_foreign` (`rol_id`),
  CONSTRAINT `users_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `rols` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Colaborador','col@osaw.com','password',NULL,NULL,1,NULL,NULL,NULL,NULL),(2,'Experto','expert@osaw.com','password',NULL,NULL,2,NULL,NULL,NULL,NULL),(3,'Administrador','admin@osaw.com','password',NULL,NULL,3,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vamolas`
--

DROP TABLE IF EXISTS `vamolas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vamolas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas_conocidos` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_conocidos_aaa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_a` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aa` int(11) NOT NULL DEFAULT '0',
  `num_problemas_potenciales_aaa` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vamolas_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `vamolas_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vamolas`
--

LOCK TABLES `vamolas` WRITE;
/*!40000 ALTER TABLE `vamolas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vamolas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waves`
--

DROP TABLE IF EXISTS `waves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `waves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_problemas` int(11) NOT NULL DEFAULT '0',
  `num_advertencias` int(11) NOT NULL DEFAULT '0',
  `num_caracteristicas` int(11) NOT NULL DEFAULT '0',
  `num_elem_ARIA` int(11) NOT NULL DEFAULT '0',
  `num_problemas_contraste` int(11) NOT NULL DEFAULT '0',
  `datos_problemas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_test` date NOT NULL,
  `pagina_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waves_pagina_id_foreign` (`pagina_id`),
  CONSTRAINT `waves_pagina_id_foreign` FOREIGN KEY (`pagina_id`) REFERENCES `paginas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waves`
--

LOCK TABLES `waves` WRITE;
/*!40000 ALTER TABLE `waves` DISABLE KEYS */;
/*!40000 ALTER TABLE `waves` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-30  3:42:33
